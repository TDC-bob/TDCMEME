missionData = 
{
    ["version"] = 6,
    ["files"] = 
    {
        [1] = "Briefing-01{225F004F-92E4-4c3e-A5F0-2BA49929055A}.jpg",
        [2] = "Thunder2.wav",
        [3] = "ExplodeGround0.ogg",
        [4] = "Rain.ogg",
    }, -- end of ["files"]
    ["startTime"] = 43200,
    ["theatre"] = "Caucasus",
    ["bullseye"] = 
    {
        ["blue"] = 
        {
            ["y"] = 617414,
            ["x"] = -291014,
        }, -- end of ["blue"]
        ["red"] = 
        {
            ["y"] = 371700,
            ["x"] = 11557,
        }, -- end of ["red"]
    }, -- end of ["bullseye"]
} -- end of missionData
