zonesByName = 
{
    ["LZ zone"] = 
    {
        ["y"] = 614105.71428571,
        ["radius"] = 3000,
        ["zoneId"] = 2,
        ["point"] = 
        {
            ["y"] = 0,
            ["x"] = -245328.57142857,
            ["z"] = 614105.71428571,
        }, -- end of ["point"]
        ["color"] = 
        {
            [1] = 1,
            [2] = 1,
            [3] = 1,
            [4] = 0.14901960784314,
        }, -- end of ["color"]
        ["x"] = -245328.57142857,
        ["hidden"] = false,
        ["name"] = "LZ zone",
    }, -- end of ["LZ zone"]
    ["explosion zone2"] = 
    {
        ["y"] = 638069.99999999,
        ["radius"] = 3000,
        ["zoneId"] = 3,
        ["point"] = 
        {
            ["y"] = 0,
            ["x"] = -298550,
            ["z"] = 638069.99999999,
        }, -- end of ["point"]
        ["color"] = 
        {
            [1] = 1,
            [2] = 1,
            [3] = 1,
            [4] = 0.14901960784314,
        }, -- end of ["color"]
        ["x"] = -298550,
        ["hidden"] = false,
        ["name"] = "explosion zone2",
    }, -- end of ["explosion zone2"]
    ["explosion zone"] = 
    {
        ["y"] = 677069.99999999,
        ["radius"] = 3000,
        ["zoneId"] = 1,
        ["point"] = 
        {
            ["y"] = 0,
            ["x"] = -271160,
            ["z"] = 677069.99999999,
        }, -- end of ["point"]
        ["color"] = 
        {
            [1] = 1,
            [2] = 1,
            [3] = 1,
            [4] = 0.14901960784314,
        }, -- end of ["color"]
        ["x"] = -271160,
        ["hidden"] = false,
        ["name"] = "explosion zone",
    }, -- end of ["explosion zone"]
} -- end of zonesByName
