unitsByName = 
{
    ["RuTent1"] = 
    {
        ["type"] = "FARP Tent",
        ["point"] = 
        {
            ["y"] = 617962.85714285,
            ["x"] = -258642.85714286,
        }, -- end of ["point"]
        ["groupId"] = 18,
        ["groupName"] = "RuTent1",
        ["countryId"] = 2,
        ["category"] = "static",
        ["unitName"] = "RuTent1",
        ["unitId"] = 40,
        ["coalition"] = "red",
        ["country"] = "Russia",
    }, -- end of ["RuTent1"]
    ["USTanks1_1"] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 639800,
            ["x"] = -294685.71428571,
        }, -- end of ["point"]
        ["groupId"] = 11,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 19,
        ["category"] = "vehicle",
        ["unitName"] = "USTanks1_1",
        ["coalition"] = "blue",
        ["groupName"] = "USTanks1",
        ["country"] = "USA",
    }, -- end of ["USTanks1_1"]
    ["Pilot #4"] = 
    {
        ["type"] = "Su-33",
        ["point"] = 
        {
            ["y"] = 590391.42857142,
            ["x"] = -250185.71428571,
        }, -- end of ["point"]
        ["groupId"] = 20,
        ["skill"] = "Client",
        ["countryId"] = 2,
        ["unitId"] = 42,
        ["category"] = "plane",
        ["unitName"] = "Pilot #4",
        ["coalition"] = "red",
        ["groupName"] = "Su-33 Client #1",
        ["country"] = "Russia",
    }, -- end of ["Pilot #4"]
    ["USTanks2_4"] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 653291.42857143,
            ["x"] = -293205.71428571,
        }, -- end of ["point"]
        ["groupId"] = 12,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 26,
        ["category"] = "vehicle",
        ["unitName"] = "USTanks2_4",
        ["coalition"] = "blue",
        ["groupName"] = "USTanks2",
        ["country"] = "USA",
    }, -- end of ["USTanks2_4"]
    ["2ship2"] = 
    {
        ["type"] = "MOSCOW",
        ["point"] = 
        {
            ["y"] = 74371.428571428,
            ["x"] = -87228.571428571,
        }, -- end of ["point"]
        ["groupId"] = 10,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 18,
        ["category"] = "ship",
        ["unitName"] = "2ship2",
        ["coalition"] = "red",
        ["groupName"] = "Rus Ships #2",
        ["country"] = "Russia",
    }, -- end of ["2ship2"]
    ["1ship2"] = 
    {
        ["type"] = "MOSCOW",
        ["point"] = 
        {
            ["y"] = 200800,
            ["x"] = -35085.714285714,
        }, -- end of ["point"]
        ["groupId"] = 9,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 16,
        ["category"] = "ship",
        ["unitName"] = "1ship2",
        ["coalition"] = "red",
        ["groupName"] = "Rus Ships #1",
        ["country"] = "Russia",
    }, -- end of ["1ship2"]
    ["AH-1s_1_2"] = 
    {
        ["type"] = "AH-1W",
        ["point"] = 
        {
            ["y"] = 631897.14285714,
            ["x"] = -297897.14285714,
        }, -- end of ["point"]
        ["groupId"] = 1,
        ["skill"] = "High",
        ["countryId"] = 11,
        ["unitId"] = 2,
        ["category"] = "helicopter",
        ["unitName"] = "AH-1s_1_2",
        ["coalition"] = "blue",
        ["groupName"] = "AH-1s_1",
        ["country"] = "USA",
    }, -- end of ["AH-1s_1_2"]
    ["1ship1"] = 
    {
        ["type"] = "MOSCOW",
        ["point"] = 
        {
            ["y"] = 200000,
            ["x"] = -34285.714285714,
        }, -- end of ["point"]
        ["groupId"] = 9,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 15,
        ["category"] = "ship",
        ["unitName"] = "1ship1",
        ["coalition"] = "red",
        ["groupName"] = "Rus Ships #1",
        ["country"] = "Russia",
    }, -- end of ["1ship1"]
    ["RuBTRs2"] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654585.71428571,
            ["x"] = -292882.85714286,
        }, -- end of ["point"]
        ["groupId"] = 13,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 28,
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs2",
        ["coalition"] = "red",
        ["groupName"] = "RuBTRs",
        ["country"] = "Russia",
    }, -- end of ["RuBTRs2"]
    ["Pilot #5"] = 
    {
        ["type"] = "A-10C",
        ["point"] = 
        {
            ["y"] = 636428.57142857,
            ["x"] = -318142.85714286,
        }, -- end of ["point"]
        ["groupId"] = 6,
        ["skill"] = "Player",
        ["countryId"] = 11,
        ["unitId"] = 11,
        ["category"] = "plane",
        ["unitName"] = "Pilot #5",
        ["coalition"] = "blue",
        ["groupName"] = "A-10C Client #1",
        ["country"] = "USA",
    }, -- end of ["Pilot #5"]
    ["AH-1s_1_1"] = 
    {
        ["type"] = "AH-1W",
        ["point"] = 
        {
            ["y"] = 631857.14285714,
            ["x"] = -297857.14285714,
        }, -- end of ["point"]
        ["groupId"] = 1,
        ["skill"] = "High",
        ["countryId"] = 11,
        ["unitId"] = 1,
        ["category"] = "helicopter",
        ["unitName"] = "AH-1s_1_1",
        ["coalition"] = "blue",
        ["groupName"] = "AH-1s_1",
        ["country"] = "USA",
    }, -- end of ["AH-1s_1_1"]
    ["USTanks2_3"] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 653251.42857143,
            ["x"] = -293165.71428571,
        }, -- end of ["point"]
        ["groupId"] = 12,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 25,
        ["category"] = "vehicle",
        ["unitName"] = "USTanks2_3",
        ["coalition"] = "blue",
        ["groupName"] = "USTanks2",
        ["country"] = "USA",
    }, -- end of ["USTanks2_3"]
    ["tent1"] = 
    {
        ["type"] = "FARP Tent",
        ["point"] = 
        {
            ["y"] = 636248.57142857,
            ["x"] = -300871.42857143,
        }, -- end of ["point"]
        ["groupId"] = 15,
        ["groupName"] = "tent1",
        ["countryId"] = 11,
        ["category"] = "static",
        ["unitName"] = "tent1",
        ["unitId"] = 37,
        ["coalition"] = "blue",
        ["country"] = "USA",
    }, -- end of ["tent1"]
    ["Pilot #6"] = 
    {
        ["type"] = "A-10C",
        ["point"] = 
        {
            ["y"] = 644428.57142857,
            ["x"] = -315857.14285714,
        }, -- end of ["point"]
        ["groupId"] = 7,
        ["skill"] = "Client",
        ["countryId"] = 11,
        ["unitId"] = 12,
        ["category"] = "plane",
        ["unitName"] = "Pilot #6",
        ["coalition"] = "blue",
        ["groupName"] = "A-10C Client #2",
        ["country"] = "USA",
    }, -- end of ["Pilot #6"]
    ["Pilot #2"] = 
    {
        ["type"] = "F-15C",
        ["point"] = 
        {
            ["y"] = 668428.57142857,
            ["x"] = -287000,
        }, -- end of ["point"]
        ["groupId"] = 5,
        ["skill"] = "Client",
        ["countryId"] = 11,
        ["unitId"] = 10,
        ["category"] = "plane",
        ["unitName"] = "Pilot #2",
        ["coalition"] = "blue",
        ["groupName"] = "F-15C Client #2",
        ["country"] = "USA",
    }, -- end of ["Pilot #2"]
    ["RuBTRs4"] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654665.71428571,
            ["x"] = -292962.85714286,
        }, -- end of ["point"]
        ["groupId"] = 13,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 30,
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs4",
        ["coalition"] = "red",
        ["groupName"] = "RuBTRs",
        ["country"] = "Russia",
    }, -- end of ["RuBTRs4"]
    ["USTanks2_1"] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 653171.42857143,
            ["x"] = -293085.71428571,
        }, -- end of ["point"]
        ["groupId"] = 12,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 23,
        ["category"] = "vehicle",
        ["unitName"] = "USTanks2_1",
        ["coalition"] = "blue",
        ["groupName"] = "USTanks2",
        ["country"] = "USA",
    }, -- end of ["USTanks2_1"]
    ["USTanks1_2"] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 639840,
            ["x"] = -294725.71428571,
        }, -- end of ["point"]
        ["groupId"] = 11,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 20,
        ["category"] = "vehicle",
        ["unitName"] = "USTanks1_2",
        ["coalition"] = "blue",
        ["groupName"] = "USTanks1",
        ["country"] = "USA",
    }, -- end of ["USTanks1_2"]
    ["US Ship #2"] = 
    {
        ["type"] = "TICONDEROG",
        ["point"] = 
        {
            ["y"] = 444657.14285714,
            ["x"] = -356085.71428571,
        }, -- end of ["point"]
        ["groupId"] = 8,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 14,
        ["category"] = "ship",
        ["unitName"] = "US Ship #2",
        ["coalition"] = "blue",
        ["groupName"] = "US Ships",
        ["country"] = "USA",
    }, -- end of ["US Ship #2"]
    ["USTanks1_3"] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 639880,
            ["x"] = -294765.71428571,
        }, -- end of ["point"]
        ["groupId"] = 11,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 21,
        ["category"] = "vehicle",
        ["unitName"] = "USTanks1_3",
        ["coalition"] = "blue",
        ["groupName"] = "USTanks1",
        ["country"] = "USA",
    }, -- end of ["USTanks1_3"]
    ["RuTent2"] = 
    {
        ["type"] = "FARP Tent",
        ["point"] = 
        {
            ["y"] = 617691.42857143,
            ["x"] = -259071.42857143,
        }, -- end of ["point"]
        ["groupId"] = 19,
        ["groupName"] = "RuTent2",
        ["countryId"] = 2,
        ["category"] = "static",
        ["unitName"] = "RuTent2",
        ["unitId"] = 41,
        ["coalition"] = "red",
        ["country"] = "Russia",
    }, -- end of ["RuTent2"]
    ["Ka-50s_1_2"] = 
    {
        ["type"] = "Ka-50",
        ["point"] = 
        {
            ["y"] = 615040,
            ["x"] = -237611.42857143,
        }, -- end of ["point"]
        ["groupId"] = 2,
        ["skill"] = "High",
        ["countryId"] = 2,
        ["unitId"] = 4,
        ["category"] = "helicopter",
        ["unitName"] = "Ka-50s_1_2",
        ["coalition"] = "red",
        ["groupName"] = "Ka-50s_1",
        ["country"] = "Russia",
    }, -- end of ["Ka-50s_1_2"]
    ["hanger"] = 
    {
        ["type"] = "Hangar A",
        ["point"] = 
        {
            ["y"] = 638084.28571428,
            ["x"] = -298535.71428571,
        }, -- end of ["point"]
        ["groupId"] = 30,
        ["groupName"] = "hanger",
        ["countryId"] = 4,
        ["category"] = "static",
        ["unitName"] = "hanger",
        ["unitId"] = 44,
        ["coalition"] = "blue",
        ["country"] = "Georgia",
    }, -- end of ["hanger"]
    ["RuTanks3"] = 
    {
        ["type"] = "T-55",
        ["point"] = 
        {
            ["y"] = 628757.14285714,
            ["x"] = -273522.85714286,
        }, -- end of ["point"]
        ["groupId"] = 14,
        ["skill"] = "Excellent",
        ["countryId"] = 2,
        ["unitId"] = 35,
        ["category"] = "vehicle",
        ["unitName"] = "RuTanks3",
        ["coalition"] = "red",
        ["groupName"] = "RuTanks",
        ["country"] = "Russia",
    }, -- end of ["RuTanks3"]
    ["USTanks2_2"] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 653211.42857143,
            ["x"] = -293125.71428571,
        }, -- end of ["point"]
        ["groupId"] = 12,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 24,
        ["category"] = "vehicle",
        ["unitName"] = "USTanks2_2",
        ["coalition"] = "blue",
        ["groupName"] = "USTanks2",
        ["country"] = "USA",
    }, -- end of ["USTanks2_2"]
    ["Ka-50s_1_1"] = 
    {
        ["type"] = "Ka-50",
        ["point"] = 
        {
            ["y"] = 615000,
            ["x"] = -237571.42857143,
        }, -- end of ["point"]
        ["groupId"] = 2,
        ["skill"] = "High",
        ["countryId"] = 2,
        ["unitId"] = 3,
        ["category"] = "helicopter",
        ["unitName"] = "Ka-50s_1_1",
        ["coalition"] = "red",
        ["groupName"] = "Ka-50s_1",
        ["country"] = "Russia",
    }, -- end of ["Ka-50s_1_1"]
    ["Pilot #7"] = 
    {
        ["type"] = "Ka-50",
        ["point"] = 
        {
            ["y"] = 604534.28571428,
            ["x"] = -250885.71428571,
        }, -- end of ["point"]
        ["groupId"] = 32,
        ["skill"] = "Client",
        ["countryId"] = 2,
        ["unitId"] = 46,
        ["category"] = "helicopter",
        ["unitName"] = "Pilot #7",
        ["coalition"] = "red",
        ["groupName"] = "Black Shark 1",
        ["country"] = "Russia",
    }, -- end of ["Pilot #7"]
    ["USTanks1_4"] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 639920,
            ["x"] = -294805.71428571,
        }, -- end of ["point"]
        ["groupId"] = 11,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 22,
        ["category"] = "vehicle",
        ["unitName"] = "USTanks1_4",
        ["coalition"] = "blue",
        ["groupName"] = "USTanks1",
        ["country"] = "USA",
    }, -- end of ["USTanks1_4"]
    ["Mi-8s_1_1 #1"] = 
    {
        ["type"] = "Mi-8MT",
        ["point"] = 
        {
            ["y"] = 603325.71428571,
            ["x"] = -243325.71428571,
        }, -- end of ["point"]
        ["groupId"] = 3,
        ["skill"] = "Random",
        ["countryId"] = 2,
        ["unitId"] = 6,
        ["category"] = "helicopter",
        ["unitName"] = "Mi-8s_1_1 #1",
        ["coalition"] = "red",
        ["groupName"] = "Mi-8s_1",
        ["country"] = "Russia",
    }, -- end of ["Mi-8s_1_1 #1"]
    ["Mi-8s_1_1"] = 
    {
        ["type"] = "Mi-8MT",
        ["point"] = 
        {
            ["y"] = 603285.71428571,
            ["x"] = -243285.71428571,
        }, -- end of ["point"]
        ["groupId"] = 3,
        ["skill"] = "Random",
        ["countryId"] = 2,
        ["unitId"] = 5,
        ["category"] = "helicopter",
        ["unitName"] = "Mi-8s_1_1",
        ["coalition"] = "red",
        ["groupName"] = "Mi-8s_1",
        ["country"] = "Russia",
    }, -- end of ["Mi-8s_1_1"]
    ["US Ship #1"] = 
    {
        ["type"] = "TICONDEROG",
        ["point"] = 
        {
            ["y"] = 443857.14285714,
            ["x"] = -355285.71428571,
        }, -- end of ["point"]
        ["groupId"] = 8,
        ["skill"] = "Average",
        ["countryId"] = 11,
        ["unitId"] = 13,
        ["category"] = "ship",
        ["unitName"] = "US Ship #1",
        ["coalition"] = "blue",
        ["groupName"] = "US Ships",
        ["country"] = "USA",
    }, -- end of ["US Ship #1"]
    ["Pilot #3"] = 
    {
        ["type"] = "Su-33",
        ["point"] = 
        {
            ["y"] = 597819.99999999,
            ["x"] = -235614.28571428,
        }, -- end of ["point"]
        ["groupId"] = 21,
        ["skill"] = "Client",
        ["countryId"] = 2,
        ["unitId"] = 43,
        ["category"] = "plane",
        ["unitName"] = "Pilot #3",
        ["coalition"] = "red",
        ["groupName"] = "Su-33 Client #2",
        ["country"] = "Russia",
    }, -- end of ["Pilot #3"]
    ["RuTanks4"] = 
    {
        ["type"] = "T-55",
        ["point"] = 
        {
            ["y"] = 628797.14285714,
            ["x"] = -273562.85714286,
        }, -- end of ["point"]
        ["groupId"] = 14,
        ["skill"] = "Excellent",
        ["countryId"] = 2,
        ["unitId"] = 36,
        ["category"] = "vehicle",
        ["unitName"] = "RuTanks4",
        ["coalition"] = "red",
        ["groupName"] = "RuTanks",
        ["country"] = "Russia",
    }, -- end of ["RuTanks4"]
    ["RuTanks2"] = 
    {
        ["type"] = "T-55",
        ["point"] = 
        {
            ["y"] = 628717.14285714,
            ["x"] = -273482.85714286,
        }, -- end of ["point"]
        ["groupId"] = 14,
        ["skill"] = "Excellent",
        ["countryId"] = 2,
        ["unitId"] = 34,
        ["category"] = "vehicle",
        ["unitName"] = "RuTanks2",
        ["coalition"] = "red",
        ["groupName"] = "RuTanks",
        ["country"] = "Russia",
    }, -- end of ["RuTanks2"]
    ["RuBTRs3"] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654625.71428571,
            ["x"] = -292922.85714286,
        }, -- end of ["point"]
        ["groupId"] = 13,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 29,
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs3",
        ["coalition"] = "red",
        ["groupName"] = "RuBTRs",
        ["country"] = "Russia",
    }, -- end of ["RuBTRs3"]
    ["RuTanks1"] = 
    {
        ["type"] = "T-55",
        ["point"] = 
        {
            ["y"] = 628677.14285714,
            ["x"] = -273442.85714286,
        }, -- end of ["point"]
        ["groupId"] = 14,
        ["skill"] = "Excellent",
        ["countryId"] = 2,
        ["unitId"] = 33,
        ["category"] = "vehicle",
        ["unitName"] = "RuTanks1",
        ["coalition"] = "red",
        ["groupName"] = "RuTanks",
        ["country"] = "Russia",
    }, -- end of ["RuTanks1"]
    ["tent2"] = 
    {
        ["type"] = "FARP Tent",
        ["point"] = 
        {
            ["y"] = 638620,
            ["x"] = -299814.28571429,
        }, -- end of ["point"]
        ["groupId"] = 16,
        ["groupName"] = "tent2",
        ["countryId"] = 11,
        ["category"] = "static",
        ["unitName"] = "tent2",
        ["unitId"] = 38,
        ["coalition"] = "blue",
        ["country"] = "USA",
    }, -- end of ["tent2"]
    ["RuBTRs6"] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654745.71428571,
            ["x"] = -293042.85714286,
        }, -- end of ["point"]
        ["groupId"] = 13,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 32,
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs6",
        ["coalition"] = "red",
        ["groupName"] = "RuBTRs",
        ["country"] = "Russia",
    }, -- end of ["RuBTRs6"]
    ["RuBTRs5"] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654705.71428571,
            ["x"] = -293002.85714286,
        }, -- end of ["point"]
        ["groupId"] = 13,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 31,
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs5",
        ["coalition"] = "red",
        ["groupName"] = "RuBTRs",
        ["country"] = "Russia",
    }, -- end of ["RuBTRs5"]
    ["2ship1"] = 
    {
        ["type"] = "MOSCOW",
        ["point"] = 
        {
            ["y"] = 73571.428571428,
            ["x"] = -86428.571428571,
        }, -- end of ["point"]
        ["groupId"] = 10,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 17,
        ["category"] = "ship",
        ["unitName"] = "2ship1",
        ["coalition"] = "red",
        ["groupName"] = "Rus Ships #2",
        ["country"] = "Russia",
    }, -- end of ["2ship1"]
    ["Pilot #1"] = 
    {
        ["type"] = "F-15C",
        ["point"] = 
        {
            ["y"] = 662142.85714286,
            ["x"] = -288142.85714286,
        }, -- end of ["point"]
        ["groupId"] = 4,
        ["skill"] = "Client",
        ["countryId"] = 11,
        ["unitId"] = 8,
        ["category"] = "plane",
        ["unitName"] = "Pilot #1",
        ["coalition"] = "blue",
        ["groupName"] = "F-15C Client #1",
        ["country"] = "USA",
    }, -- end of ["Pilot #1"]
    ["RuBTRs1"] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654545.71428571,
            ["x"] = -292842.85714286,
        }, -- end of ["point"]
        ["groupId"] = 13,
        ["skill"] = "Average",
        ["countryId"] = 2,
        ["unitId"] = 27,
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs1",
        ["coalition"] = "red",
        ["groupName"] = "RuBTRs",
        ["country"] = "Russia",
    }, -- end of ["RuBTRs1"]
    ["RU Farp"] = 
    {
        ["type"] = "FARP",
        ["point"] = 
        {
            ["y"] = 617591.42857143,
            ["x"] = -258442.85714286,
        }, -- end of ["point"]
        ["groupId"] = 17,
        ["groupName"] = "RU Farp",
        ["countryId"] = 2,
        ["category"] = "static",
        ["unitName"] = "RU Farp",
        ["unitId"] = 39,
        ["coalition"] = "red",
        ["country"] = "Russia",
    }, -- end of ["RU Farp"]
} -- end of unitsByName
