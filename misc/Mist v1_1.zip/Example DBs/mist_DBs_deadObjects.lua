deadObjects = 
{
    [270121831] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 100.8946762085,
            ["x"] = -271174.9375,
            ["z"] = 677058.3125,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121831,
        }, -- end of ["object"]
    }, -- end of [270121831]
    [270121832] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 101.16453552246,
            ["x"] = -271136,
            ["z"] = 677063.0625,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121832,
        }, -- end of ["object"]
    }, -- end of [270121832]
    [270121833] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 101.08447265625,
            ["x"] = -271155.125,
            ["z"] = 677090.3125,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121833,
        }, -- end of ["object"]
    }, -- end of [270121833]
    [270121834] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 101.17022705078,
            ["x"] = -271142.75,
            ["z"] = 677091.8125,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121834,
        }, -- end of ["object"]
    }, -- end of [270121834]
    [270121835] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 101.24948120117,
            ["x"] = -271131.3125,
            ["z"] = 677093.25,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121835,
        }, -- end of ["object"]
    }, -- end of [270121835]
    [16780288] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 22.308540344238,
            ["x"] = -292849.6875,
            ["z"] = 654476.75,
        }, -- end of ["objectPos"]
        ["objectType"] = "vehicle",
        ["objectData"] = 
        {
            ["type"] = "BTR-80",
            ["point"] = 
            {
                ["y"] = 654625.71428571,
                ["x"] = -292922.85714286,
            }, -- end of ["point"]
            ["groupId"] = 13,
            ["skill"] = "Average",
            ["unit"] = 
            {
                ["id_"] = 16780288,
            }, -- end of ["unit"]
            ["countryId"] = 2,
            ["country"] = "Russia",
            ["coalition"] = "red",
            ["category"] = "vehicle",
            ["unitName"] = "RuBTRs3",
            ["groupName"] = "RuBTRs",
            ["unitId"] = 29,
            ["pos"] = 
            {
                ["y"] = 22.308471679688,
                ["x"] = -292849.6875,
                ["z"] = 654476.8125,
            }, -- end of ["pos"]
        }, -- end of ["objectData"]
        ["object"] = 
        {
            ["id_"] = 16780288,
        }, -- end of ["object"]
    }, -- end of [16780288]
    [16779776] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 22.510915756226,
            ["x"] = -292873.78125,
            ["z"] = 654412.6875,
        }, -- end of ["objectPos"]
        ["objectType"] = "vehicle",
        ["objectData"] = 
        {
            ["type"] = "BTR-80",
            ["point"] = 
            {
                ["y"] = 654545.71428571,
                ["x"] = -292842.85714286,
            }, -- end of ["point"]
            ["groupId"] = 13,
            ["skill"] = "Average",
            ["unit"] = 
            {
                ["id_"] = 16779776,
            }, -- end of ["unit"]
            ["countryId"] = 2,
            ["country"] = "Russia",
            ["coalition"] = "red",
            ["category"] = "vehicle",
            ["unitName"] = "RuBTRs1",
            ["groupName"] = "RuBTRs",
            ["unitId"] = 27,
            ["pos"] = 
            {
                ["y"] = 22.510150909424,
                ["x"] = -292873.71875,
                ["z"] = 654413,
            }, -- end of ["pos"]
        }, -- end of ["objectData"]
        ["object"] = 
        {
            ["id_"] = 16779776,
        }, -- end of ["object"]
    }, -- end of [16779776]
    [270121838] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 101.09619903564,
            ["x"] = -271156.625,
            ["z"] = 677102.6875,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121838,
        }, -- end of ["object"]
    }, -- end of [270121838]
    [270121839] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 101.17977142334,
            ["x"] = -271144.5625,
            ["z"] = 677104.125,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121839,
        }, -- end of ["object"]
    }, -- end of [270121839]
    [270121804] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 100.73825836182,
            ["x"] = -271178.15625,
            ["z"] = 676982.25,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121804,
        }, -- end of ["object"]
    }, -- end of [270121804]
    [16780032] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 22.366388320923,
            ["x"] = -292861.75,
            ["z"] = 654464.4375,
        }, -- end of ["objectPos"]
        ["objectType"] = "vehicle",
        ["objectData"] = 
        {
            ["type"] = "BTR-80",
            ["point"] = 
            {
                ["y"] = 654585.71428571,
                ["x"] = -292882.85714286,
            }, -- end of ["point"]
            ["groupId"] = 13,
            ["skill"] = "Average",
            ["unit"] = 
            {
                ["id_"] = 16780032,
            }, -- end of ["unit"]
            ["countryId"] = 2,
            ["country"] = "Russia",
            ["coalition"] = "red",
            ["category"] = "vehicle",
            ["unitName"] = "RuBTRs2",
            ["groupName"] = "RuBTRs",
            ["unitId"] = 28,
            ["pos"] = 
            {
                ["y"] = 22.361045837402,
                ["x"] = -292861.3125,
                ["z"] = 654466.3125,
            }, -- end of ["pos"]
        }, -- end of ["objectData"]
        ["object"] = 
        {
            ["id_"] = 16780032,
        }, -- end of ["object"]
    }, -- end of [16780032]
    [8000976] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 12.924202919006,
            ["x"] = -298535.71875,
            ["z"] = 638084.3125,
        }, -- end of ["objectPos"]
        ["objectType"] = "static",
        ["objectData"] = 
        {
            ["type"] = "Hangar A",
            ["point"] = 
            {
                ["y"] = 638084.28571428,
                ["x"] = -298535.71428571,
            }, -- end of ["point"]
            ["groupId"] = 30,
            ["groupName"] = "hanger",
            ["countryId"] = 4,
            ["category"] = "static",
            ["unitName"] = "hanger",
            ["unitId"] = 44,
            ["coalition"] = "blue",
            ["country"] = "Georgia",
        }, -- end of ["objectData"]
        ["object"] = 
        {
            ["id_"] = 8000976,
        }, -- end of ["object"]
    }, -- end of [8000976]
    [16778752] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 499.78076171875,
            ["x"] = -238044.875,
            ["z"] = 615287.8125,
        }, -- end of ["objectPos"]
        ["objectType"] = "helicopter",
        ["objectData"] = 
        {
            ["type"] = "Ka-50",
            ["point"] = 
            {
                ["y"] = 615000,
                ["x"] = -237571.42857143,
            }, -- end of ["point"]
            ["groupId"] = 2,
            ["skill"] = "High",
            ["unit"] = 
            {
                ["id_"] = 16778752,
            }, -- end of ["unit"]
            ["countryId"] = 2,
            ["country"] = "Russia",
            ["coalition"] = "red",
            ["category"] = "helicopter",
            ["unitName"] = "Ka-50s_1_1",
            ["groupName"] = "Ka-50s_1",
            ["unitId"] = 3,
            ["pos"] = 
            {
                ["y"] = 499.78500366211,
                ["x"] = -238035.3125,
                ["z"] = 615282,
            }, -- end of ["pos"]
        }, -- end of ["objectData"]
        ["object"] = 
        {
            ["id_"] = 16778752,
        }, -- end of ["object"]
    }, -- end of [16778752]
    [270121802] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 101.28695678711,
            ["x"] = -271135.09375,
            ["z"] = 677128.75,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121802,
        }, -- end of ["object"]
    }, -- end of [270121802]
    [270121803] = 
    {
        ["objectPos"] = 
        {
            ["y"] = 101.25902557373,
            ["x"] = -271133.125,
            ["z"] = 677105.5625,
        }, -- end of ["objectPos"]
        ["objectType"] = "building",
        ["object"] = 
        {
            ["id_"] = 270121803,
        }, -- end of ["object"]
    }, -- end of [270121803]
} -- end of deadObjects
