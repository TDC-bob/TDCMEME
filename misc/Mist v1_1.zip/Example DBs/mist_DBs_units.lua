units = 
{
    ["blue"] = 
    {
        ["Norway"] = 
        {
            ["countryId"] = 13,
        }, -- end of ["Norway"]
        ["France"] = 
        {
            ["countryId"] = 5,
        }, -- end of ["France"]
        ["USA"] = 
        {
            ["countryId"] = 11,
            ["ship"] = 
            {
                [1] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "ship",
                    ["groupId"] = 8,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "US Ships",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "TICONDEROG",
                            ["point"] = 
                            {
                                ["y"] = 443857.14285714,
                                ["x"] = -355285.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 8,
                            ["category"] = "ship",
                            ["unitName"] = "US Ship #1",
                            ["groupName"] = "US Ships",
                            ["coalition"] = "blue",
                            ["unitId"] = 13,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "TICONDEROG",
                            ["point"] = 
                            {
                                ["y"] = 444657.14285714,
                                ["x"] = -356085.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 8,
                            ["category"] = "ship",
                            ["unitName"] = "US Ship #2",
                            ["groupName"] = "US Ships",
                            ["coalition"] = "blue",
                            ["unitId"] = 14,
                        }, -- end of [2]
                    }, -- end of ["units"]
                }, -- end of [1]
            }, -- end of ["ship"]
            ["static"] = 
            {
                [1] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "static",
                    ["groupId"] = 15,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "tent1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "FARP Tent",
                            ["point"] = 
                            {
                                ["y"] = 636248.57142857,
                                ["x"] = -300871.42857143,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["groupName"] = "tent1",
                            ["countryId"] = 11,
                            ["category"] = "static",
                            ["unitName"] = "tent1",
                            ["groupId"] = 15,
                            ["coalition"] = "blue",
                            ["unitId"] = 37,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [1]
                [2] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "static",
                    ["groupId"] = 16,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "tent2",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "FARP Tent",
                            ["point"] = 
                            {
                                ["y"] = 638620,
                                ["x"] = -299814.28571429,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["groupName"] = "tent2",
                            ["countryId"] = 11,
                            ["category"] = "static",
                            ["unitName"] = "tent2",
                            ["groupId"] = 16,
                            ["coalition"] = "blue",
                            ["unitId"] = 38,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [2]
            }, -- end of ["static"]
            ["vehicle"] = 
            {
                [1] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "vehicle",
                    ["groupId"] = 11,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "USTanks1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "M-1 Abrams",
                            ["point"] = 
                            {
                                ["y"] = 639800,
                                ["x"] = -294685.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 11,
                            ["category"] = "vehicle",
                            ["unitName"] = "USTanks1_1",
                            ["groupName"] = "USTanks1",
                            ["coalition"] = "blue",
                            ["unitId"] = 19,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "M-1 Abrams",
                            ["point"] = 
                            {
                                ["y"] = 639840,
                                ["x"] = -294725.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 11,
                            ["category"] = "vehicle",
                            ["unitName"] = "USTanks1_2",
                            ["groupName"] = "USTanks1",
                            ["coalition"] = "blue",
                            ["unitId"] = 20,
                        }, -- end of [2]
                        [3] = 
                        {
                            ["type"] = "M-1 Abrams",
                            ["point"] = 
                            {
                                ["y"] = 639880,
                                ["x"] = -294765.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 11,
                            ["category"] = "vehicle",
                            ["unitName"] = "USTanks1_3",
                            ["groupName"] = "USTanks1",
                            ["coalition"] = "blue",
                            ["unitId"] = 21,
                        }, -- end of [3]
                        [4] = 
                        {
                            ["type"] = "M-1 Abrams",
                            ["point"] = 
                            {
                                ["y"] = 639920,
                                ["x"] = -294805.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 11,
                            ["category"] = "vehicle",
                            ["unitName"] = "USTanks1_4",
                            ["groupName"] = "USTanks1",
                            ["coalition"] = "blue",
                            ["unitId"] = 22,
                        }, -- end of [4]
                    }, -- end of ["units"]
                }, -- end of [1]
                [2] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "vehicle",
                    ["groupId"] = 12,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "USTanks2",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "M-1 Abrams",
                            ["point"] = 
                            {
                                ["y"] = 653171.42857143,
                                ["x"] = -293085.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 12,
                            ["category"] = "vehicle",
                            ["unitName"] = "USTanks2_1",
                            ["groupName"] = "USTanks2",
                            ["coalition"] = "blue",
                            ["unitId"] = 23,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "M-1 Abrams",
                            ["point"] = 
                            {
                                ["y"] = 653211.42857143,
                                ["x"] = -293125.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 12,
                            ["category"] = "vehicle",
                            ["unitName"] = "USTanks2_2",
                            ["groupName"] = "USTanks2",
                            ["coalition"] = "blue",
                            ["unitId"] = 24,
                        }, -- end of [2]
                        [3] = 
                        {
                            ["type"] = "M-1 Abrams",
                            ["point"] = 
                            {
                                ["y"] = 653251.42857143,
                                ["x"] = -293165.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 12,
                            ["category"] = "vehicle",
                            ["unitName"] = "USTanks2_3",
                            ["groupName"] = "USTanks2",
                            ["coalition"] = "blue",
                            ["unitId"] = 25,
                        }, -- end of [3]
                        [4] = 
                        {
                            ["type"] = "M-1 Abrams",
                            ["point"] = 
                            {
                                ["y"] = 653291.42857143,
                                ["x"] = -293205.71428571,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Average",
                            ["countryId"] = 11,
                            ["groupId"] = 12,
                            ["category"] = "vehicle",
                            ["unitName"] = "USTanks2_4",
                            ["groupName"] = "USTanks2",
                            ["coalition"] = "blue",
                            ["unitId"] = 26,
                        }, -- end of [4]
                    }, -- end of ["units"]
                }, -- end of [2]
            }, -- end of ["vehicle"]
            ["plane"] = 
            {
                [1] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "plane",
                    ["groupId"] = 4,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "F-15C Client #1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "F-15C",
                            ["point"] = 
                            {
                                ["y"] = 662142.85714286,
                                ["x"] = -288142.85714286,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Client",
                            ["countryId"] = 11,
                            ["groupId"] = 4,
                            ["category"] = "plane",
                            ["unitName"] = "Pilot #1",
                            ["groupName"] = "F-15C Client #1",
                            ["coalition"] = "blue",
                            ["unitId"] = 8,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [1]
                [2] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "plane",
                    ["groupId"] = 5,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "F-15C Client #2",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "F-15C",
                            ["point"] = 
                            {
                                ["y"] = 668428.57142857,
                                ["x"] = -287000,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Client",
                            ["countryId"] = 11,
                            ["groupId"] = 5,
                            ["category"] = "plane",
                            ["unitName"] = "Pilot #2",
                            ["groupName"] = "F-15C Client #2",
                            ["coalition"] = "blue",
                            ["unitId"] = 10,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [2]
                [3] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "plane",
                    ["groupId"] = 6,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "A-10C Client #1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "A-10C",
                            ["point"] = 
                            {
                                ["y"] = 636428.57142857,
                                ["x"] = -318142.85714286,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Player",
                            ["countryId"] = 11,
                            ["groupId"] = 6,
                            ["category"] = "plane",
                            ["unitName"] = "Pilot #5",
                            ["groupName"] = "A-10C Client #1",
                            ["coalition"] = "blue",
                            ["unitId"] = 11,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [3]
                [4] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "plane",
                    ["groupId"] = 7,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "A-10C Client #2",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "A-10C",
                            ["point"] = 
                            {
                                ["y"] = 644428.57142857,
                                ["x"] = -315857.14285714,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "Client",
                            ["countryId"] = 11,
                            ["groupId"] = 7,
                            ["category"] = "plane",
                            ["unitName"] = "Pilot #6",
                            ["groupName"] = "A-10C Client #2",
                            ["coalition"] = "blue",
                            ["unitId"] = 12,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [4]
            }, -- end of ["plane"]
            ["helicopter"] = 
            {
                [1] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "helicopter",
                    ["groupId"] = 1,
                    ["countryId"] = 11,
                    ["country"] = "USA",
                    ["groupName"] = "AH-1s_1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "AH-1W",
                            ["point"] = 
                            {
                                ["y"] = 631857.14285714,
                                ["x"] = -297857.14285714,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "High",
                            ["countryId"] = 11,
                            ["groupId"] = 1,
                            ["category"] = "helicopter",
                            ["unitName"] = "AH-1s_1_1",
                            ["groupName"] = "AH-1s_1",
                            ["coalition"] = "blue",
                            ["unitId"] = 1,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "AH-1W",
                            ["point"] = 
                            {
                                ["y"] = 631897.14285714,
                                ["x"] = -297897.14285714,
                            }, -- end of ["point"]
                            ["country"] = "USA",
                            ["skill"] = "High",
                            ["countryId"] = 11,
                            ["groupId"] = 1,
                            ["category"] = "helicopter",
                            ["unitName"] = "AH-1s_1_2",
                            ["groupName"] = "AH-1s_1",
                            ["coalition"] = "blue",
                            ["unitId"] = 2,
                        }, -- end of [2]
                    }, -- end of ["units"]
                }, -- end of [1]
            }, -- end of ["helicopter"]
        }, -- end of ["USA"]
        ["Georgia"] = 
        {
            ["countryId"] = 4,
            ["static"] = 
            {
                [1] = 
                {
                    ["coalition"] = "blue",
                    ["category"] = "static",
                    ["groupId"] = 30,
                    ["countryId"] = 4,
                    ["country"] = "Georgia",
                    ["groupName"] = "hanger",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "Hangar A",
                            ["point"] = 
                            {
                                ["y"] = 638084.28571428,
                                ["x"] = -298535.71428571,
                            }, -- end of ["point"]
                            ["country"] = "Georgia",
                            ["groupName"] = "hanger",
                            ["countryId"] = 4,
                            ["category"] = "static",
                            ["unitName"] = "hanger",
                            ["groupId"] = 30,
                            ["coalition"] = "blue",
                            ["unitId"] = 44,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [1]
            }, -- end of ["static"]
        }, -- end of ["Georgia"]
        ["The Netherlands"] = 
        {
            ["countryId"] = 15,
        }, -- end of ["The Netherlands"]
        ["Ukraine"] = 
        {
            ["countryId"] = 7,
        }, -- end of ["Ukraine"]
        ["Belgium"] = 
        {
            ["countryId"] = 6,
        }, -- end of ["Belgium"]
        ["Israel"] = 
        {
            ["countryId"] = 12,
        }, -- end of ["Israel"]
        ["Denmark"] = 
        {
            ["countryId"] = 2,
        }, -- end of ["Denmark"]
        ["Italy"] = 
        {
            ["countryId"] = 9,
        }, -- end of ["Italy"]
        ["Canada"] = 
        {
            ["countryId"] = 8,
        }, -- end of ["Canada"]
        ["Germany"] = 
        {
            ["countryId"] = 3,
        }, -- end of ["Germany"]
        ["Turkey"] = 
        {
            ["countryId"] = 14,
        }, -- end of ["Turkey"]
        ["UK"] = 
        {
            ["countryId"] = 1,
        }, -- end of ["UK"]
        ["Spain"] = 
        {
            ["countryId"] = 10,
        }, -- end of ["Spain"]
    }, -- end of ["blue"]
    ["red"] = 
    {
        ["Russia"] = 
        {
            ["countryId"] = 2,
            ["ship"] = 
            {
                [1] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "ship",
                    ["groupId"] = 9,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "Rus Ships #1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "MOSCOW",
                            ["point"] = 
                            {
                                ["y"] = 200000,
                                ["x"] = -34285.714285714,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 9,
                            ["category"] = "ship",
                            ["unitName"] = "1ship1",
                            ["groupName"] = "Rus Ships #1",
                            ["coalition"] = "red",
                            ["unitId"] = 15,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "MOSCOW",
                            ["point"] = 
                            {
                                ["y"] = 200800,
                                ["x"] = -35085.714285714,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 9,
                            ["category"] = "ship",
                            ["unitName"] = "1ship2",
                            ["groupName"] = "Rus Ships #1",
                            ["coalition"] = "red",
                            ["unitId"] = 16,
                        }, -- end of [2]
                    }, -- end of ["units"]
                }, -- end of [1]
                [2] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "ship",
                    ["groupId"] = 10,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "Rus Ships #2",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "MOSCOW",
                            ["point"] = 
                            {
                                ["y"] = 73571.428571428,
                                ["x"] = -86428.571428571,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 10,
                            ["category"] = "ship",
                            ["unitName"] = "2ship1",
                            ["groupName"] = "Rus Ships #2",
                            ["coalition"] = "red",
                            ["unitId"] = 17,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "MOSCOW",
                            ["point"] = 
                            {
                                ["y"] = 74371.428571428,
                                ["x"] = -87228.571428571,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 10,
                            ["category"] = "ship",
                            ["unitName"] = "2ship2",
                            ["groupName"] = "Rus Ships #2",
                            ["coalition"] = "red",
                            ["unitId"] = 18,
                        }, -- end of [2]
                    }, -- end of ["units"]
                }, -- end of [2]
            }, -- end of ["ship"]
            ["static"] = 
            {
                [1] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "static",
                    ["groupId"] = 17,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "RU Farp",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "FARP",
                            ["point"] = 
                            {
                                ["y"] = 617591.42857143,
                                ["x"] = -258442.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["groupName"] = "RU Farp",
                            ["countryId"] = 2,
                            ["category"] = "static",
                            ["unitName"] = "RU Farp",
                            ["groupId"] = 17,
                            ["coalition"] = "red",
                            ["unitId"] = 39,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [1]
                [2] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "static",
                    ["groupId"] = 18,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "RuTent1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "FARP Tent",
                            ["point"] = 
                            {
                                ["y"] = 617962.85714285,
                                ["x"] = -258642.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["groupName"] = "RuTent1",
                            ["countryId"] = 2,
                            ["category"] = "static",
                            ["unitName"] = "RuTent1",
                            ["groupId"] = 18,
                            ["coalition"] = "red",
                            ["unitId"] = 40,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [2]
                [3] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "static",
                    ["groupId"] = 19,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "RuTent2",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "FARP Tent",
                            ["point"] = 
                            {
                                ["y"] = 617691.42857143,
                                ["x"] = -259071.42857143,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["groupName"] = "RuTent2",
                            ["countryId"] = 2,
                            ["category"] = "static",
                            ["unitName"] = "RuTent2",
                            ["groupId"] = 19,
                            ["coalition"] = "red",
                            ["unitId"] = 41,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [3]
            }, -- end of ["static"]
            ["vehicle"] = 
            {
                [1] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "vehicle",
                    ["groupId"] = 13,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "RuBTRs",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "BTR-80",
                            ["point"] = 
                            {
                                ["y"] = 654545.71428571,
                                ["x"] = -292842.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 13,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuBTRs1",
                            ["groupName"] = "RuBTRs",
                            ["coalition"] = "red",
                            ["unitId"] = 27,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "BTR-80",
                            ["point"] = 
                            {
                                ["y"] = 654585.71428571,
                                ["x"] = -292882.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 13,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuBTRs2",
                            ["groupName"] = "RuBTRs",
                            ["coalition"] = "red",
                            ["unitId"] = 28,
                        }, -- end of [2]
                        [3] = 
                        {
                            ["type"] = "BTR-80",
                            ["point"] = 
                            {
                                ["y"] = 654625.71428571,
                                ["x"] = -292922.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 13,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuBTRs3",
                            ["groupName"] = "RuBTRs",
                            ["coalition"] = "red",
                            ["unitId"] = 29,
                        }, -- end of [3]
                        [4] = 
                        {
                            ["type"] = "BTR-80",
                            ["point"] = 
                            {
                                ["y"] = 654665.71428571,
                                ["x"] = -292962.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 13,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuBTRs4",
                            ["groupName"] = "RuBTRs",
                            ["coalition"] = "red",
                            ["unitId"] = 30,
                        }, -- end of [4]
                        [5] = 
                        {
                            ["type"] = "BTR-80",
                            ["point"] = 
                            {
                                ["y"] = 654705.71428571,
                                ["x"] = -293002.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 13,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuBTRs5",
                            ["groupName"] = "RuBTRs",
                            ["coalition"] = "red",
                            ["unitId"] = 31,
                        }, -- end of [5]
                        [6] = 
                        {
                            ["type"] = "BTR-80",
                            ["point"] = 
                            {
                                ["y"] = 654745.71428571,
                                ["x"] = -293042.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Average",
                            ["countryId"] = 2,
                            ["groupId"] = 13,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuBTRs6",
                            ["groupName"] = "RuBTRs",
                            ["coalition"] = "red",
                            ["unitId"] = 32,
                        }, -- end of [6]
                    }, -- end of ["units"]
                }, -- end of [1]
                [2] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "vehicle",
                    ["groupId"] = 14,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "RuTanks",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "T-55",
                            ["point"] = 
                            {
                                ["y"] = 628677.14285714,
                                ["x"] = -273442.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Excellent",
                            ["countryId"] = 2,
                            ["groupId"] = 14,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuTanks1",
                            ["groupName"] = "RuTanks",
                            ["coalition"] = "red",
                            ["unitId"] = 33,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "T-55",
                            ["point"] = 
                            {
                                ["y"] = 628717.14285714,
                                ["x"] = -273482.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Excellent",
                            ["countryId"] = 2,
                            ["groupId"] = 14,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuTanks2",
                            ["groupName"] = "RuTanks",
                            ["coalition"] = "red",
                            ["unitId"] = 34,
                        }, -- end of [2]
                        [3] = 
                        {
                            ["type"] = "T-55",
                            ["point"] = 
                            {
                                ["y"] = 628757.14285714,
                                ["x"] = -273522.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Excellent",
                            ["countryId"] = 2,
                            ["groupId"] = 14,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuTanks3",
                            ["groupName"] = "RuTanks",
                            ["coalition"] = "red",
                            ["unitId"] = 35,
                        }, -- end of [3]
                        [4] = 
                        {
                            ["type"] = "T-55",
                            ["point"] = 
                            {
                                ["y"] = 628797.14285714,
                                ["x"] = -273562.85714286,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Excellent",
                            ["countryId"] = 2,
                            ["groupId"] = 14,
                            ["category"] = "vehicle",
                            ["unitName"] = "RuTanks4",
                            ["groupName"] = "RuTanks",
                            ["coalition"] = "red",
                            ["unitId"] = 36,
                        }, -- end of [4]
                    }, -- end of ["units"]
                }, -- end of [2]
            }, -- end of ["vehicle"]
            ["plane"] = 
            {
                [1] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "plane",
                    ["groupId"] = 20,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "Su-33 Client #1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "Su-33",
                            ["point"] = 
                            {
                                ["y"] = 590391.42857142,
                                ["x"] = -250185.71428571,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Client",
                            ["countryId"] = 2,
                            ["groupId"] = 20,
                            ["category"] = "plane",
                            ["unitName"] = "Pilot #4",
                            ["groupName"] = "Su-33 Client #1",
                            ["coalition"] = "red",
                            ["unitId"] = 42,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [1]
                [2] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "plane",
                    ["groupId"] = 21,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "Su-33 Client #2",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "Su-33",
                            ["point"] = 
                            {
                                ["y"] = 597819.99999999,
                                ["x"] = -235614.28571428,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Client",
                            ["countryId"] = 2,
                            ["groupId"] = 21,
                            ["category"] = "plane",
                            ["unitName"] = "Pilot #3",
                            ["groupName"] = "Su-33 Client #2",
                            ["coalition"] = "red",
                            ["unitId"] = 43,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [2]
            }, -- end of ["plane"]
            ["helicopter"] = 
            {
                [1] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "helicopter",
                    ["groupId"] = 2,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "Ka-50s_1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "Ka-50",
                            ["point"] = 
                            {
                                ["y"] = 615000,
                                ["x"] = -237571.42857143,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "High",
                            ["countryId"] = 2,
                            ["groupId"] = 2,
                            ["category"] = "helicopter",
                            ["unitName"] = "Ka-50s_1_1",
                            ["groupName"] = "Ka-50s_1",
                            ["coalition"] = "red",
                            ["unitId"] = 3,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "Ka-50",
                            ["point"] = 
                            {
                                ["y"] = 615040,
                                ["x"] = -237611.42857143,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "High",
                            ["countryId"] = 2,
                            ["groupId"] = 2,
                            ["category"] = "helicopter",
                            ["unitName"] = "Ka-50s_1_2",
                            ["groupName"] = "Ka-50s_1",
                            ["coalition"] = "red",
                            ["unitId"] = 4,
                        }, -- end of [2]
                    }, -- end of ["units"]
                }, -- end of [1]
                [2] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "helicopter",
                    ["groupId"] = 3,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "Mi-8s_1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "Mi-8MT",
                            ["point"] = 
                            {
                                ["y"] = 603285.71428571,
                                ["x"] = -243285.71428571,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Random",
                            ["countryId"] = 2,
                            ["groupId"] = 3,
                            ["category"] = "helicopter",
                            ["unitName"] = "Mi-8s_1_1",
                            ["groupName"] = "Mi-8s_1",
                            ["coalition"] = "red",
                            ["unitId"] = 5,
                        }, -- end of [1]
                        [2] = 
                        {
                            ["type"] = "Mi-8MT",
                            ["point"] = 
                            {
                                ["y"] = 603325.71428571,
                                ["x"] = -243325.71428571,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Random",
                            ["countryId"] = 2,
                            ["groupId"] = 3,
                            ["category"] = "helicopter",
                            ["unitName"] = "Mi-8s_1_1 #1",
                            ["groupName"] = "Mi-8s_1",
                            ["coalition"] = "red",
                            ["unitId"] = 6,
                        }, -- end of [2]
                    }, -- end of ["units"]
                }, -- end of [2]
                [3] = 
                {
                    ["coalition"] = "red",
                    ["category"] = "helicopter",
                    ["groupId"] = 32,
                    ["countryId"] = 2,
                    ["country"] = "Russia",
                    ["groupName"] = "Black Shark 1",
                    ["units"] = 
                    {
                        [1] = 
                        {
                            ["type"] = "Ka-50",
                            ["point"] = 
                            {
                                ["y"] = 604534.28571428,
                                ["x"] = -250885.71428571,
                            }, -- end of ["point"]
                            ["country"] = "Russia",
                            ["skill"] = "Client",
                            ["countryId"] = 2,
                            ["groupId"] = 32,
                            ["category"] = "helicopter",
                            ["unitName"] = "Pilot #7",
                            ["groupName"] = "Black Shark 1",
                            ["coalition"] = "red",
                            ["unitId"] = 46,
                        }, -- end of [1]
                    }, -- end of ["units"]
                }, -- end of [3]
            }, -- end of ["helicopter"]
        }, -- end of ["Russia"]
        ["Abkhazia"] = 
        {
            ["countryId"] = 1,
        }, -- end of ["Abkhazia"]
        ["South Ossetia"] = 
        {
            ["countryId"] = 3,
        }, -- end of ["South Ossetia"]
    }, -- end of ["red"]
} -- end of units
