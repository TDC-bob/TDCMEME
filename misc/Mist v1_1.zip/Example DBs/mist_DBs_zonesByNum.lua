zonesByNum = 
{
    [1] = 
    {
        ["y"] = 677069.99999999,
        ["radius"] = 3000,
        ["point"] = 
        {
            ["y"] = 0,
            ["x"] = -271160,
            ["z"] = 677069.99999999,
        }, -- end of ["point"]
        ["name"] = "explosion zone",
        ["color"] = 
        {
            [1] = 1,
            [2] = 1,
            [3] = 1,
            [4] = 0.14901960784314,
        }, -- end of ["color"]
        ["x"] = -271160,
        ["hidden"] = false,
        ["zoneId"] = 1,
    }, -- end of [1]
    [2] = 
    {
        ["y"] = 614105.71428571,
        ["radius"] = 3000,
        ["point"] = 
        {
            ["y"] = 0,
            ["x"] = -245328.57142857,
            ["z"] = 614105.71428571,
        }, -- end of ["point"]
        ["name"] = "LZ zone",
        ["color"] = 
        {
            [1] = 1,
            [2] = 1,
            [3] = 1,
            [4] = 0.14901960784314,
        }, -- end of ["color"]
        ["x"] = -245328.57142857,
        ["hidden"] = false,
        ["zoneId"] = 2,
    }, -- end of [2]
    [3] = 
    {
        ["y"] = 638069.99999999,
        ["radius"] = 3000,
        ["point"] = 
        {
            ["y"] = 0,
            ["x"] = -298550,
            ["z"] = 638069.99999999,
        }, -- end of ["point"]
        ["name"] = "explosion zone2",
        ["color"] = 
        {
            [1] = 1,
            [2] = 1,
            [3] = 1,
            [4] = 0.14901960784314,
        }, -- end of ["color"]
        ["x"] = -298550,
        ["hidden"] = false,
        ["zoneId"] = 3,
    }, -- end of [3]
} -- end of zonesByNum
