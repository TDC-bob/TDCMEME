removedAliveUnits = 
{
    [16778752] = 
    {
        ["type"] = "Ka-50",
        ["point"] = 
        {
            ["y"] = 615000,
            ["x"] = -237571.42857143,
        }, -- end of ["point"]
        ["unitId"] = 3,
        ["skill"] = "High",
        ["unit"] = 
        {
            ["id_"] = 16778752,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 2,
        ["country"] = "Russia",
        ["category"] = "helicopter",
        ["unitName"] = "Ka-50s_1_1",
        ["groupName"] = "Ka-50s_1",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 499.78500366211,
            ["x"] = -238035.3125,
            ["z"] = 615282,
        }, -- end of ["pos"]
    }, -- end of [16778752]
    [16779776] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654545.71428571,
            ["x"] = -292842.85714286,
        }, -- end of ["point"]
        ["unitId"] = 27,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16779776,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 13,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs1",
        ["groupName"] = "RuBTRs",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 22.510150909424,
            ["x"] = -292873.71875,
            ["z"] = 654413,
        }, -- end of ["pos"]
    }, -- end of [16779776]
    [16780032] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654585.71428571,
            ["x"] = -292882.85714286,
        }, -- end of ["point"]
        ["unitId"] = 28,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16780032,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 13,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs2",
        ["groupName"] = "RuBTRs",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 22.361045837402,
            ["x"] = -292861.3125,
            ["z"] = 654466.3125,
        }, -- end of ["pos"]
    }, -- end of [16780032]
    [16780288] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654625.71428571,
            ["x"] = -292922.85714286,
        }, -- end of ["point"]
        ["unitId"] = 29,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16780288,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 13,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs3",
        ["groupName"] = "RuBTRs",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 22.308471679688,
            ["x"] = -292849.6875,
            ["z"] = 654476.8125,
        }, -- end of ["pos"]
    }, -- end of [16780288]
} -- end of removedAliveUnits
