groupsByName = 
{
    ["RuTent1"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 18,
        ["category"] = "static",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "RuTent1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "FARP Tent",
                ["point"] = 
                {
                    ["y"] = 617962.85714285,
                    ["x"] = -258642.85714286,
                }, -- end of ["point"]
                ["groupId"] = 18,
                ["groupName"] = "RuTent1",
                ["countryId"] = 2,
                ["category"] = "static",
                ["unitName"] = "RuTent1",
                ["unitId"] = 40,
                ["coalition"] = "red",
                ["country"] = "Russia",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["RuTent1"]
    ["F-15C Client #1"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 4,
        ["category"] = "plane",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "F-15C Client #1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "F-15C",
                ["point"] = 
                {
                    ["y"] = 662142.85714286,
                    ["x"] = -288142.85714286,
                }, -- end of ["point"]
                ["groupId"] = 4,
                ["skill"] = "Client",
                ["countryId"] = 11,
                ["unitId"] = 8,
                ["category"] = "plane",
                ["unitName"] = "Pilot #1",
                ["coalition"] = "blue",
                ["groupName"] = "F-15C Client #1",
                ["country"] = "USA",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["F-15C Client #1"]
    ["USTanks2"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 12,
        ["category"] = "vehicle",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "USTanks2",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "M-1 Abrams",
                ["point"] = 
                {
                    ["y"] = 653171.42857143,
                    ["x"] = -293085.71428571,
                }, -- end of ["point"]
                ["groupId"] = 12,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 23,
                ["category"] = "vehicle",
                ["unitName"] = "USTanks2_1",
                ["coalition"] = "blue",
                ["groupName"] = "USTanks2",
                ["country"] = "USA",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "M-1 Abrams",
                ["point"] = 
                {
                    ["y"] = 653211.42857143,
                    ["x"] = -293125.71428571,
                }, -- end of ["point"]
                ["groupId"] = 12,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 24,
                ["category"] = "vehicle",
                ["unitName"] = "USTanks2_2",
                ["coalition"] = "blue",
                ["groupName"] = "USTanks2",
                ["country"] = "USA",
            }, -- end of [2]
            [3] = 
            {
                ["type"] = "M-1 Abrams",
                ["point"] = 
                {
                    ["y"] = 653251.42857143,
                    ["x"] = -293165.71428571,
                }, -- end of ["point"]
                ["groupId"] = 12,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 25,
                ["category"] = "vehicle",
                ["unitName"] = "USTanks2_3",
                ["coalition"] = "blue",
                ["groupName"] = "USTanks2",
                ["country"] = "USA",
            }, -- end of [3]
            [4] = 
            {
                ["type"] = "M-1 Abrams",
                ["point"] = 
                {
                    ["y"] = 653291.42857143,
                    ["x"] = -293205.71428571,
                }, -- end of ["point"]
                ["groupId"] = 12,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 26,
                ["category"] = "vehicle",
                ["unitName"] = "USTanks2_4",
                ["coalition"] = "blue",
                ["groupName"] = "USTanks2",
                ["country"] = "USA",
            }, -- end of [4]
        }, -- end of ["units"]
    }, -- end of ["USTanks2"]
    ["Rus Ships #2"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 10,
        ["category"] = "ship",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "Rus Ships #2",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "MOSCOW",
                ["point"] = 
                {
                    ["y"] = 73571.428571428,
                    ["x"] = -86428.571428571,
                }, -- end of ["point"]
                ["groupId"] = 10,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 17,
                ["category"] = "ship",
                ["unitName"] = "2ship1",
                ["coalition"] = "red",
                ["groupName"] = "Rus Ships #2",
                ["country"] = "Russia",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "MOSCOW",
                ["point"] = 
                {
                    ["y"] = 74371.428571428,
                    ["x"] = -87228.571428571,
                }, -- end of ["point"]
                ["groupId"] = 10,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 18,
                ["category"] = "ship",
                ["unitName"] = "2ship2",
                ["coalition"] = "red",
                ["groupName"] = "Rus Ships #2",
                ["country"] = "Russia",
            }, -- end of [2]
        }, -- end of ["units"]
    }, -- end of ["Rus Ships #2"]
    ["hanger"] = 
    {
        ["countryId"] = 4,
        ["groupId"] = 30,
        ["category"] = "static",
        ["coalition"] = "blue",
        ["country"] = "Georgia",
        ["groupName"] = "hanger",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "Hangar A",
                ["point"] = 
                {
                    ["y"] = 638084.28571428,
                    ["x"] = -298535.71428571,
                }, -- end of ["point"]
                ["groupId"] = 30,
                ["groupName"] = "hanger",
                ["countryId"] = 4,
                ["category"] = "static",
                ["unitName"] = "hanger",
                ["unitId"] = 44,
                ["coalition"] = "blue",
                ["country"] = "Georgia",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["hanger"]
    ["AH-1s_1"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 1,
        ["category"] = "helicopter",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "AH-1s_1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "AH-1W",
                ["point"] = 
                {
                    ["y"] = 631857.14285714,
                    ["x"] = -297857.14285714,
                }, -- end of ["point"]
                ["groupId"] = 1,
                ["skill"] = "High",
                ["countryId"] = 11,
                ["unitId"] = 1,
                ["category"] = "helicopter",
                ["unitName"] = "AH-1s_1_1",
                ["coalition"] = "blue",
                ["groupName"] = "AH-1s_1",
                ["country"] = "USA",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "AH-1W",
                ["point"] = 
                {
                    ["y"] = 631897.14285714,
                    ["x"] = -297897.14285714,
                }, -- end of ["point"]
                ["groupId"] = 1,
                ["skill"] = "High",
                ["countryId"] = 11,
                ["unitId"] = 2,
                ["category"] = "helicopter",
                ["unitName"] = "AH-1s_1_2",
                ["coalition"] = "blue",
                ["groupName"] = "AH-1s_1",
                ["country"] = "USA",
            }, -- end of [2]
        }, -- end of ["units"]
    }, -- end of ["AH-1s_1"]
    ["Ka-50s_1"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 2,
        ["category"] = "helicopter",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "Ka-50s_1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "Ka-50",
                ["point"] = 
                {
                    ["y"] = 615000,
                    ["x"] = -237571.42857143,
                }, -- end of ["point"]
                ["groupId"] = 2,
                ["skill"] = "High",
                ["countryId"] = 2,
                ["unitId"] = 3,
                ["category"] = "helicopter",
                ["unitName"] = "Ka-50s_1_1",
                ["coalition"] = "red",
                ["groupName"] = "Ka-50s_1",
                ["country"] = "Russia",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "Ka-50",
                ["point"] = 
                {
                    ["y"] = 615040,
                    ["x"] = -237611.42857143,
                }, -- end of ["point"]
                ["groupId"] = 2,
                ["skill"] = "High",
                ["countryId"] = 2,
                ["unitId"] = 4,
                ["category"] = "helicopter",
                ["unitName"] = "Ka-50s_1_2",
                ["coalition"] = "red",
                ["groupName"] = "Ka-50s_1",
                ["country"] = "Russia",
            }, -- end of [2]
        }, -- end of ["units"]
    }, -- end of ["Ka-50s_1"]
    ["RuTent2"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 19,
        ["category"] = "static",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "RuTent2",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "FARP Tent",
                ["point"] = 
                {
                    ["y"] = 617691.42857143,
                    ["x"] = -259071.42857143,
                }, -- end of ["point"]
                ["groupId"] = 19,
                ["groupName"] = "RuTent2",
                ["countryId"] = 2,
                ["category"] = "static",
                ["unitName"] = "RuTent2",
                ["unitId"] = 41,
                ["coalition"] = "red",
                ["country"] = "Russia",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["RuTent2"]
    ["F-15C Client #2"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 5,
        ["category"] = "plane",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "F-15C Client #2",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "F-15C",
                ["point"] = 
                {
                    ["y"] = 668428.57142857,
                    ["x"] = -287000,
                }, -- end of ["point"]
                ["groupId"] = 5,
                ["skill"] = "Client",
                ["countryId"] = 11,
                ["unitId"] = 10,
                ["category"] = "plane",
                ["unitName"] = "Pilot #2",
                ["coalition"] = "blue",
                ["groupName"] = "F-15C Client #2",
                ["country"] = "USA",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["F-15C Client #2"]
    ["A-10C Client #1"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 6,
        ["category"] = "plane",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "A-10C Client #1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "A-10C",
                ["point"] = 
                {
                    ["y"] = 636428.57142857,
                    ["x"] = -318142.85714286,
                }, -- end of ["point"]
                ["groupId"] = 6,
                ["skill"] = "Player",
                ["countryId"] = 11,
                ["unitId"] = 11,
                ["category"] = "plane",
                ["unitName"] = "Pilot #5",
                ["coalition"] = "blue",
                ["groupName"] = "A-10C Client #1",
                ["country"] = "USA",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["A-10C Client #1"]
    ["A-10C Client #2"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 7,
        ["category"] = "plane",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "A-10C Client #2",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "A-10C",
                ["point"] = 
                {
                    ["y"] = 644428.57142857,
                    ["x"] = -315857.14285714,
                }, -- end of ["point"]
                ["groupId"] = 7,
                ["skill"] = "Client",
                ["countryId"] = 11,
                ["unitId"] = 12,
                ["category"] = "plane",
                ["unitName"] = "Pilot #6",
                ["coalition"] = "blue",
                ["groupName"] = "A-10C Client #2",
                ["country"] = "USA",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["A-10C Client #2"]
    ["tent1"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 15,
        ["category"] = "static",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "tent1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "FARP Tent",
                ["point"] = 
                {
                    ["y"] = 636248.57142857,
                    ["x"] = -300871.42857143,
                }, -- end of ["point"]
                ["groupId"] = 15,
                ["groupName"] = "tent1",
                ["countryId"] = 11,
                ["category"] = "static",
                ["unitName"] = "tent1",
                ["unitId"] = 37,
                ["coalition"] = "blue",
                ["country"] = "USA",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["tent1"]
    ["RuTanks"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 14,
        ["category"] = "vehicle",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "RuTanks",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "T-55",
                ["point"] = 
                {
                    ["y"] = 628677.14285714,
                    ["x"] = -273442.85714286,
                }, -- end of ["point"]
                ["groupId"] = 14,
                ["skill"] = "Excellent",
                ["countryId"] = 2,
                ["unitId"] = 33,
                ["category"] = "vehicle",
                ["unitName"] = "RuTanks1",
                ["coalition"] = "red",
                ["groupName"] = "RuTanks",
                ["country"] = "Russia",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "T-55",
                ["point"] = 
                {
                    ["y"] = 628717.14285714,
                    ["x"] = -273482.85714286,
                }, -- end of ["point"]
                ["groupId"] = 14,
                ["skill"] = "Excellent",
                ["countryId"] = 2,
                ["unitId"] = 34,
                ["category"] = "vehicle",
                ["unitName"] = "RuTanks2",
                ["coalition"] = "red",
                ["groupName"] = "RuTanks",
                ["country"] = "Russia",
            }, -- end of [2]
            [3] = 
            {
                ["type"] = "T-55",
                ["point"] = 
                {
                    ["y"] = 628757.14285714,
                    ["x"] = -273522.85714286,
                }, -- end of ["point"]
                ["groupId"] = 14,
                ["skill"] = "Excellent",
                ["countryId"] = 2,
                ["unitId"] = 35,
                ["category"] = "vehicle",
                ["unitName"] = "RuTanks3",
                ["coalition"] = "red",
                ["groupName"] = "RuTanks",
                ["country"] = "Russia",
            }, -- end of [3]
            [4] = 
            {
                ["type"] = "T-55",
                ["point"] = 
                {
                    ["y"] = 628797.14285714,
                    ["x"] = -273562.85714286,
                }, -- end of ["point"]
                ["groupId"] = 14,
                ["skill"] = "Excellent",
                ["countryId"] = 2,
                ["unitId"] = 36,
                ["category"] = "vehicle",
                ["unitName"] = "RuTanks4",
                ["coalition"] = "red",
                ["groupName"] = "RuTanks",
                ["country"] = "Russia",
            }, -- end of [4]
        }, -- end of ["units"]
    }, -- end of ["RuTanks"]
    ["US Ships"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 8,
        ["category"] = "ship",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "US Ships",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "TICONDEROG",
                ["point"] = 
                {
                    ["y"] = 443857.14285714,
                    ["x"] = -355285.71428571,
                }, -- end of ["point"]
                ["groupId"] = 8,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 13,
                ["category"] = "ship",
                ["unitName"] = "US Ship #1",
                ["coalition"] = "blue",
                ["groupName"] = "US Ships",
                ["country"] = "USA",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "TICONDEROG",
                ["point"] = 
                {
                    ["y"] = 444657.14285714,
                    ["x"] = -356085.71428571,
                }, -- end of ["point"]
                ["groupId"] = 8,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 14,
                ["category"] = "ship",
                ["unitName"] = "US Ship #2",
                ["coalition"] = "blue",
                ["groupName"] = "US Ships",
                ["country"] = "USA",
            }, -- end of [2]
        }, -- end of ["units"]
    }, -- end of ["US Ships"]
    ["Rus Ships #1"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 9,
        ["category"] = "ship",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "Rus Ships #1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "MOSCOW",
                ["point"] = 
                {
                    ["y"] = 200000,
                    ["x"] = -34285.714285714,
                }, -- end of ["point"]
                ["groupId"] = 9,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 15,
                ["category"] = "ship",
                ["unitName"] = "1ship1",
                ["coalition"] = "red",
                ["groupName"] = "Rus Ships #1",
                ["country"] = "Russia",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "MOSCOW",
                ["point"] = 
                {
                    ["y"] = 200800,
                    ["x"] = -35085.714285714,
                }, -- end of ["point"]
                ["groupId"] = 9,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 16,
                ["category"] = "ship",
                ["unitName"] = "1ship2",
                ["coalition"] = "red",
                ["groupName"] = "Rus Ships #1",
                ["country"] = "Russia",
            }, -- end of [2]
        }, -- end of ["units"]
    }, -- end of ["Rus Ships #1"]
    ["Su-33 Client #1"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 20,
        ["category"] = "plane",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "Su-33 Client #1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "Su-33",
                ["point"] = 
                {
                    ["y"] = 590391.42857142,
                    ["x"] = -250185.71428571,
                }, -- end of ["point"]
                ["groupId"] = 20,
                ["skill"] = "Client",
                ["countryId"] = 2,
                ["unitId"] = 42,
                ["category"] = "plane",
                ["unitName"] = "Pilot #4",
                ["coalition"] = "red",
                ["groupName"] = "Su-33 Client #1",
                ["country"] = "Russia",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["Su-33 Client #1"]
    ["tent2"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 16,
        ["category"] = "static",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "tent2",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "FARP Tent",
                ["point"] = 
                {
                    ["y"] = 638620,
                    ["x"] = -299814.28571429,
                }, -- end of ["point"]
                ["groupId"] = 16,
                ["groupName"] = "tent2",
                ["countryId"] = 11,
                ["category"] = "static",
                ["unitName"] = "tent2",
                ["unitId"] = 38,
                ["coalition"] = "blue",
                ["country"] = "USA",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["tent2"]
    ["RU Farp"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 17,
        ["category"] = "static",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "RU Farp",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "FARP",
                ["point"] = 
                {
                    ["y"] = 617591.42857143,
                    ["x"] = -258442.85714286,
                }, -- end of ["point"]
                ["groupId"] = 17,
                ["groupName"] = "RU Farp",
                ["countryId"] = 2,
                ["category"] = "static",
                ["unitName"] = "RU Farp",
                ["unitId"] = 39,
                ["coalition"] = "red",
                ["country"] = "Russia",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["RU Farp"]
    ["USTanks1"] = 
    {
        ["countryId"] = 11,
        ["groupId"] = 11,
        ["category"] = "vehicle",
        ["coalition"] = "blue",
        ["country"] = "USA",
        ["groupName"] = "USTanks1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "M-1 Abrams",
                ["point"] = 
                {
                    ["y"] = 639800,
                    ["x"] = -294685.71428571,
                }, -- end of ["point"]
                ["groupId"] = 11,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 19,
                ["category"] = "vehicle",
                ["unitName"] = "USTanks1_1",
                ["coalition"] = "blue",
                ["groupName"] = "USTanks1",
                ["country"] = "USA",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "M-1 Abrams",
                ["point"] = 
                {
                    ["y"] = 639840,
                    ["x"] = -294725.71428571,
                }, -- end of ["point"]
                ["groupId"] = 11,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 20,
                ["category"] = "vehicle",
                ["unitName"] = "USTanks1_2",
                ["coalition"] = "blue",
                ["groupName"] = "USTanks1",
                ["country"] = "USA",
            }, -- end of [2]
            [3] = 
            {
                ["type"] = "M-1 Abrams",
                ["point"] = 
                {
                    ["y"] = 639880,
                    ["x"] = -294765.71428571,
                }, -- end of ["point"]
                ["groupId"] = 11,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 21,
                ["category"] = "vehicle",
                ["unitName"] = "USTanks1_3",
                ["coalition"] = "blue",
                ["groupName"] = "USTanks1",
                ["country"] = "USA",
            }, -- end of [3]
            [4] = 
            {
                ["type"] = "M-1 Abrams",
                ["point"] = 
                {
                    ["y"] = 639920,
                    ["x"] = -294805.71428571,
                }, -- end of ["point"]
                ["groupId"] = 11,
                ["skill"] = "Average",
                ["countryId"] = 11,
                ["unitId"] = 22,
                ["category"] = "vehicle",
                ["unitName"] = "USTanks1_4",
                ["coalition"] = "blue",
                ["groupName"] = "USTanks1",
                ["country"] = "USA",
            }, -- end of [4]
        }, -- end of ["units"]
    }, -- end of ["USTanks1"]
    ["Black Shark 1"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 32,
        ["category"] = "helicopter",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "Black Shark 1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "Ka-50",
                ["point"] = 
                {
                    ["y"] = 604534.28571428,
                    ["x"] = -250885.71428571,
                }, -- end of ["point"]
                ["groupId"] = 32,
                ["skill"] = "Client",
                ["countryId"] = 2,
                ["unitId"] = 46,
                ["category"] = "helicopter",
                ["unitName"] = "Pilot #7",
                ["coalition"] = "red",
                ["groupName"] = "Black Shark 1",
                ["country"] = "Russia",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["Black Shark 1"]
    ["Mi-8s_1"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 3,
        ["category"] = "helicopter",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "Mi-8s_1",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "Mi-8MT",
                ["point"] = 
                {
                    ["y"] = 603285.71428571,
                    ["x"] = -243285.71428571,
                }, -- end of ["point"]
                ["groupId"] = 3,
                ["skill"] = "Random",
                ["countryId"] = 2,
                ["unitId"] = 5,
                ["category"] = "helicopter",
                ["unitName"] = "Mi-8s_1_1",
                ["coalition"] = "red",
                ["groupName"] = "Mi-8s_1",
                ["country"] = "Russia",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "Mi-8MT",
                ["point"] = 
                {
                    ["y"] = 603325.71428571,
                    ["x"] = -243325.71428571,
                }, -- end of ["point"]
                ["groupId"] = 3,
                ["skill"] = "Random",
                ["countryId"] = 2,
                ["unitId"] = 6,
                ["category"] = "helicopter",
                ["unitName"] = "Mi-8s_1_1 #1",
                ["coalition"] = "red",
                ["groupName"] = "Mi-8s_1",
                ["country"] = "Russia",
            }, -- end of [2]
        }, -- end of ["units"]
    }, -- end of ["Mi-8s_1"]
    ["Su-33 Client #2"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 21,
        ["category"] = "plane",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "Su-33 Client #2",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "Su-33",
                ["point"] = 
                {
                    ["y"] = 597819.99999999,
                    ["x"] = -235614.28571428,
                }, -- end of ["point"]
                ["groupId"] = 21,
                ["skill"] = "Client",
                ["countryId"] = 2,
                ["unitId"] = 43,
                ["category"] = "plane",
                ["unitName"] = "Pilot #3",
                ["coalition"] = "red",
                ["groupName"] = "Su-33 Client #2",
                ["country"] = "Russia",
            }, -- end of [1]
        }, -- end of ["units"]
    }, -- end of ["Su-33 Client #2"]
    ["RuBTRs"] = 
    {
        ["countryId"] = 2,
        ["groupId"] = 13,
        ["category"] = "vehicle",
        ["coalition"] = "red",
        ["country"] = "Russia",
        ["groupName"] = "RuBTRs",
        ["units"] = 
        {
            [1] = 
            {
                ["type"] = "BTR-80",
                ["point"] = 
                {
                    ["y"] = 654545.71428571,
                    ["x"] = -292842.85714286,
                }, -- end of ["point"]
                ["groupId"] = 13,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 27,
                ["category"] = "vehicle",
                ["unitName"] = "RuBTRs1",
                ["coalition"] = "red",
                ["groupName"] = "RuBTRs",
                ["country"] = "Russia",
            }, -- end of [1]
            [2] = 
            {
                ["type"] = "BTR-80",
                ["point"] = 
                {
                    ["y"] = 654585.71428571,
                    ["x"] = -292882.85714286,
                }, -- end of ["point"]
                ["groupId"] = 13,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 28,
                ["category"] = "vehicle",
                ["unitName"] = "RuBTRs2",
                ["coalition"] = "red",
                ["groupName"] = "RuBTRs",
                ["country"] = "Russia",
            }, -- end of [2]
            [3] = 
            {
                ["type"] = "BTR-80",
                ["point"] = 
                {
                    ["y"] = 654625.71428571,
                    ["x"] = -292922.85714286,
                }, -- end of ["point"]
                ["groupId"] = 13,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 29,
                ["category"] = "vehicle",
                ["unitName"] = "RuBTRs3",
                ["coalition"] = "red",
                ["groupName"] = "RuBTRs",
                ["country"] = "Russia",
            }, -- end of [3]
            [4] = 
            {
                ["type"] = "BTR-80",
                ["point"] = 
                {
                    ["y"] = 654665.71428571,
                    ["x"] = -292962.85714286,
                }, -- end of ["point"]
                ["groupId"] = 13,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 30,
                ["category"] = "vehicle",
                ["unitName"] = "RuBTRs4",
                ["coalition"] = "red",
                ["groupName"] = "RuBTRs",
                ["country"] = "Russia",
            }, -- end of [4]
            [5] = 
            {
                ["type"] = "BTR-80",
                ["point"] = 
                {
                    ["y"] = 654705.71428571,
                    ["x"] = -293002.85714286,
                }, -- end of ["point"]
                ["groupId"] = 13,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 31,
                ["category"] = "vehicle",
                ["unitName"] = "RuBTRs5",
                ["coalition"] = "red",
                ["groupName"] = "RuBTRs",
                ["country"] = "Russia",
            }, -- end of [5]
            [6] = 
            {
                ["type"] = "BTR-80",
                ["point"] = 
                {
                    ["y"] = 654745.71428571,
                    ["x"] = -293042.85714286,
                }, -- end of ["point"]
                ["groupId"] = 13,
                ["skill"] = "Average",
                ["countryId"] = 2,
                ["unitId"] = 32,
                ["category"] = "vehicle",
                ["unitName"] = "RuBTRs6",
                ["coalition"] = "red",
                ["groupName"] = "RuBTRs",
                ["country"] = "Russia",
            }, -- end of [6]
        }, -- end of ["units"]
    }, -- end of ["RuBTRs"]
} -- end of groupsByName
