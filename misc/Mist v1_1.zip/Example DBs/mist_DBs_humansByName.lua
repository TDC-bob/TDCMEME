humansByName = 
{
    ["Pilot #5"] = 
    {
        ["type"] = "A-10C",
        ["point"] = 
        {
            ["y"] = 636428.57142857,
            ["x"] = -318142.85714286,
        }, -- end of ["point"]
        ["groupId"] = 6,
        ["skill"] = "Player",
        ["countryId"] = 11,
        ["unitId"] = 11,
        ["category"] = "plane",
        ["unitName"] = "Pilot #5",
        ["coalition"] = "blue",
        ["groupName"] = "A-10C Client #1",
        ["country"] = "USA",
    }, -- end of ["Pilot #5"]
    ["Pilot #7"] = 
    {
        ["type"] = "Ka-50",
        ["point"] = 
        {
            ["y"] = 604534.28571428,
            ["x"] = -250885.71428571,
        }, -- end of ["point"]
        ["groupId"] = 32,
        ["skill"] = "Client",
        ["countryId"] = 2,
        ["unitId"] = 46,
        ["category"] = "helicopter",
        ["unitName"] = "Pilot #7",
        ["coalition"] = "red",
        ["groupName"] = "Black Shark 1",
        ["country"] = "Russia",
    }, -- end of ["Pilot #7"]
    ["Pilot #3"] = 
    {
        ["type"] = "Su-33",
        ["point"] = 
        {
            ["y"] = 597819.99999999,
            ["x"] = -235614.28571428,
        }, -- end of ["point"]
        ["groupId"] = 21,
        ["skill"] = "Client",
        ["countryId"] = 2,
        ["unitId"] = 43,
        ["category"] = "plane",
        ["unitName"] = "Pilot #3",
        ["coalition"] = "red",
        ["groupName"] = "Su-33 Client #2",
        ["country"] = "Russia",
    }, -- end of ["Pilot #3"]
    ["Pilot #1"] = 
    {
        ["type"] = "F-15C",
        ["point"] = 
        {
            ["y"] = 662142.85714286,
            ["x"] = -288142.85714286,
        }, -- end of ["point"]
        ["groupId"] = 4,
        ["skill"] = "Client",
        ["countryId"] = 11,
        ["unitId"] = 8,
        ["category"] = "plane",
        ["unitName"] = "Pilot #1",
        ["coalition"] = "blue",
        ["groupName"] = "F-15C Client #1",
        ["country"] = "USA",
    }, -- end of ["Pilot #1"]
    ["Pilot #4"] = 
    {
        ["type"] = "Su-33",
        ["point"] = 
        {
            ["y"] = 590391.42857142,
            ["x"] = -250185.71428571,
        }, -- end of ["point"]
        ["groupId"] = 20,
        ["skill"] = "Client",
        ["countryId"] = 2,
        ["unitId"] = 42,
        ["category"] = "plane",
        ["unitName"] = "Pilot #4",
        ["coalition"] = "red",
        ["groupName"] = "Su-33 Client #1",
        ["country"] = "Russia",
    }, -- end of ["Pilot #4"]
    ["Pilot #6"] = 
    {
        ["type"] = "A-10C",
        ["point"] = 
        {
            ["y"] = 644428.57142857,
            ["x"] = -315857.14285714,
        }, -- end of ["point"]
        ["groupId"] = 7,
        ["skill"] = "Client",
        ["countryId"] = 11,
        ["unitId"] = 12,
        ["category"] = "plane",
        ["unitName"] = "Pilot #6",
        ["coalition"] = "blue",
        ["groupName"] = "A-10C Client #2",
        ["country"] = "USA",
    }, -- end of ["Pilot #6"]
    ["Pilot #2"] = 
    {
        ["type"] = "F-15C",
        ["point"] = 
        {
            ["y"] = 668428.57142857,
            ["x"] = -287000,
        }, -- end of ["point"]
        ["groupId"] = 5,
        ["skill"] = "Client",
        ["countryId"] = 11,
        ["unitId"] = 10,
        ["category"] = "plane",
        ["unitName"] = "Pilot #2",
        ["coalition"] = "blue",
        ["groupName"] = "F-15C Client #2",
        ["country"] = "USA",
    }, -- end of ["Pilot #2"]
} -- end of humansByName
