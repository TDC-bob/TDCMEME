aliveUnits = 
{
    [16780800] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654705.71428571,
            ["x"] = -293002.85714286,
        }, -- end of ["point"]
        ["unitId"] = 31,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16780800,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 13,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs5",
        ["groupName"] = "RuBTRs",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 22.27530670166,
            ["x"] = -292856.78125,
            ["z"] = 654497.1875,
        }, -- end of ["pos"]
    }, -- end of [16780800]
    [16781312] = 
    {
        ["type"] = "T-55",
        ["point"] = 
        {
            ["y"] = 628677.14285714,
            ["x"] = -273442.85714286,
        }, -- end of ["point"]
        ["unitId"] = 33,
        ["skill"] = "Excellent",
        ["unit"] = 
        {
            ["id_"] = 16781312,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 14,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuTanks1",
        ["groupName"] = "RuTanks",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 10.380812644958,
            ["x"] = -273442.84375,
            ["z"] = 628677.125,
        }, -- end of ["pos"]
    }, -- end of [16781312]
    [16781824] = 
    {
        ["type"] = "T-55",
        ["point"] = 
        {
            ["y"] = 628757.14285714,
            ["x"] = -273522.85714286,
        }, -- end of ["point"]
        ["unitId"] = 35,
        ["skill"] = "Excellent",
        ["unit"] = 
        {
            ["id_"] = 16781824,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 14,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuTanks3",
        ["groupName"] = "RuTanks",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 10.263838768005,
            ["x"] = -273522.84375,
            ["z"] = 628757.125,
        }, -- end of ["pos"]
    }, -- end of [16781824]
    [16782336] = 
    {
        ["type"] = "TICONDEROG",
        ["point"] = 
        {
            ["y"] = 443857.14285714,
            ["x"] = -355285.71428571,
        }, -- end of ["point"]
        ["unitId"] = 13,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16782336,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 8,
        ["country"] = "USA",
        ["category"] = "ship",
        ["unitName"] = "US Ship #1",
        ["groupName"] = "US Ships",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = -0.048762038350105,
            ["x"] = -355217.75,
            ["z"] = 443857.1875,
        }, -- end of ["pos"]
    }, -- end of [16782336]
    [16782848] = 
    {
        ["type"] = "AH-1W",
        ["point"] = 
        {
            ["y"] = 631857.14285714,
            ["x"] = -297857.14285714,
        }, -- end of ["point"]
        ["unitId"] = 1,
        ["skill"] = "High",
        ["unit"] = 
        {
            ["id_"] = 16782848,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 1,
        ["country"] = "USA",
        ["category"] = "helicopter",
        ["unitName"] = "AH-1s_1_1",
        ["groupName"] = "AH-1s_1",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 499.41860961914,
            ["x"] = -294625.125,
            ["z"] = 631913.3125,
        }, -- end of ["pos"]
    }, -- end of [16782848]
    [16783360] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 639800,
            ["x"] = -294685.71428571,
        }, -- end of ["point"]
        ["unitId"] = 19,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16783360,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 11,
        ["country"] = "USA",
        ["category"] = "vehicle",
        ["unitName"] = "USTanks1_1",
        ["groupName"] = "USTanks1",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 7.5028886795044,
            ["x"] = -294685.71875,
            ["z"] = 639800,
        }, -- end of ["pos"]
    }, -- end of [16783360]
    [16783872] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 639880,
            ["x"] = -294765.71428571,
        }, -- end of ["point"]
        ["unitId"] = 21,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16783872,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 11,
        ["country"] = "USA",
        ["category"] = "vehicle",
        ["unitName"] = "USTanks1_3",
        ["groupName"] = "USTanks1",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 7.7261953353882,
            ["x"] = -294765.71875,
            ["z"] = 639880,
        }, -- end of ["pos"]
    }, -- end of [16783872]
    [16784384] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 653171.42857143,
            ["x"] = -293085.71428571,
        }, -- end of ["point"]
        ["unitId"] = 23,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16784384,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 12,
        ["country"] = "USA",
        ["category"] = "vehicle",
        ["unitName"] = "USTanks2_1",
        ["groupName"] = "USTanks2",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 19.896106719971,
            ["x"] = -293063.15625,
            ["z"] = 653479.6875,
        }, -- end of ["pos"]
    }, -- end of [16784384]
    [16784896] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 653251.42857143,
            ["x"] = -293165.71428571,
        }, -- end of ["point"]
        ["unitId"] = 25,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16784896,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 12,
        ["country"] = "USA",
        ["category"] = "vehicle",
        ["unitName"] = "USTanks2_3",
        ["groupName"] = "USTanks2",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 19.629573822021,
            ["x"] = -293067.15625,
            ["z"] = 653425.125,
        }, -- end of ["pos"]
    }, -- end of [16784896]
    [16785408] = 
    {
        ["type"] = "A-10C",
        ["point"] = 
        {
            ["y"] = 636428.57142857,
            ["x"] = -318142.85714286,
        }, -- end of ["point"]
        ["unitId"] = 11,
        ["skill"] = "Player",
        ["unit"] = 
        {
            ["id_"] = 16785408,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 6,
        ["country"] = "USA",
        ["category"] = "plane",
        ["unitName"] = "Pilot #5",
        ["groupName"] = "A-10C Client #1",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 2455.0166015625,
            ["x"] = -311237.5625,
            ["z"] = 630905.1875,
        }, -- end of ["pos"]
    }, -- end of [16785408]
    [16777984] = 
    {
        ["type"] = "MOSCOW",
        ["point"] = 
        {
            ["y"] = 200800,
            ["x"] = -35085.714285714,
        }, -- end of ["point"]
        ["unitId"] = 16,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16777984,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 9,
        ["country"] = "Russia",
        ["category"] = "ship",
        ["unitName"] = "1ship2",
        ["groupName"] = "Rus Ships #1",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = -0.038766741752625,
            ["x"] = -35022.9375,
            ["z"] = 200799.984375,
        }, -- end of ["pos"]
    }, -- end of [16777984]
    [16778496] = 
    {
        ["type"] = "MOSCOW",
        ["point"] = 
        {
            ["y"] = 74371.428571428,
            ["x"] = -87228.571428571,
        }, -- end of ["point"]
        ["unitId"] = 18,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16778496,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 10,
        ["country"] = "Russia",
        ["category"] = "ship",
        ["unitName"] = "2ship2",
        ["groupName"] = "Rus Ships #2",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = -0.038807597011328,
            ["x"] = -87204.390625,
            ["z"] = 74429.3671875,
        }, -- end of ["pos"]
    }, -- end of [16778496]
    [16779008] = 
    {
        ["type"] = "Ka-50",
        ["point"] = 
        {
            ["y"] = 615040,
            ["x"] = -237611.42857143,
        }, -- end of ["point"]
        ["unitId"] = 4,
        ["skill"] = "High",
        ["unit"] = 
        {
            ["id_"] = 16779008,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 2,
        ["country"] = "Russia",
        ["category"] = "helicopter",
        ["unitName"] = "Ka-50s_1_2",
        ["groupName"] = "Ka-50s_1",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 499.87216186523,
            ["x"] = -240100.125,
            ["z"] = 616595.4375,
        }, -- end of ["pos"]
    }, -- end of [16779008]
    [16779520] = 
    {
        ["type"] = "Mi-8MT",
        ["point"] = 
        {
            ["y"] = 603325.71428571,
            ["x"] = -243325.71428571,
        }, -- end of ["point"]
        ["unitId"] = 6,
        ["skill"] = "Random",
        ["unit"] = 
        {
            ["id_"] = 16779520,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 3,
        ["country"] = "Russia",
        ["category"] = "helicopter",
        ["unitName"] = "Mi-8s_1_1 #1",
        ["groupName"] = "Mi-8s_1",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 508.82904052734,
            ["x"] = -246094.4375,
            ["z"] = 604987.4375,
        }, -- end of ["pos"]
    }, -- end of [16779520]
    [16780544] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654665.71428571,
            ["x"] = -292962.85714286,
        }, -- end of ["point"]
        ["unitId"] = 30,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16780544,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 13,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs4",
        ["groupName"] = "RuBTRs",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 22.351711273193,
            ["x"] = -292861.5625,
            ["z"] = 654470.8125,
        }, -- end of ["pos"]
    }, -- end of [16780544]
    [16781056] = 
    {
        ["type"] = "BTR-80",
        ["point"] = 
        {
            ["y"] = 654745.71428571,
            ["x"] = -293042.85714286,
        }, -- end of ["point"]
        ["unitId"] = 32,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16781056,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 13,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuBTRs6",
        ["groupName"] = "RuBTRs",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 22.143859863281,
            ["x"] = -292846.625,
            ["z"] = 654531.5625,
        }, -- end of ["pos"]
    }, -- end of [16781056]
    [16781568] = 
    {
        ["type"] = "T-55",
        ["point"] = 
        {
            ["y"] = 628717.14285714,
            ["x"] = -273482.85714286,
        }, -- end of ["point"]
        ["unitId"] = 34,
        ["skill"] = "Excellent",
        ["unit"] = 
        {
            ["id_"] = 16781568,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 14,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuTanks2",
        ["groupName"] = "RuTanks",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 10.385926246643,
            ["x"] = -273482.84375,
            ["z"] = 628717.125,
        }, -- end of ["pos"]
    }, -- end of [16781568]
    [16782080] = 
    {
        ["type"] = "T-55",
        ["point"] = 
        {
            ["y"] = 628797.14285714,
            ["x"] = -273562.85714286,
        }, -- end of ["point"]
        ["unitId"] = 36,
        ["skill"] = "Excellent",
        ["unit"] = 
        {
            ["id_"] = 16782080,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 14,
        ["country"] = "Russia",
        ["category"] = "vehicle",
        ["unitName"] = "RuTanks4",
        ["groupName"] = "RuTanks",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 10.182079315186,
            ["x"] = -273562.84375,
            ["z"] = 628797.125,
        }, -- end of ["pos"]
    }, -- end of [16782080]
    [16782592] = 
    {
        ["type"] = "TICONDEROG",
        ["point"] = 
        {
            ["y"] = 444657.14285714,
            ["x"] = -356085.71428571,
        }, -- end of ["point"]
        ["unitId"] = 14,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16782592,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 8,
        ["country"] = "USA",
        ["category"] = "ship",
        ["unitName"] = "US Ship #2",
        ["groupName"] = "US Ships",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = -0.048697948455811,
            ["x"] = -356017.75,
            ["z"] = 444657.15625,
        }, -- end of ["pos"]
    }, -- end of [16782592]
    [16783104] = 
    {
        ["type"] = "AH-1W",
        ["point"] = 
        {
            ["y"] = 631897.14285714,
            ["x"] = -297897.14285714,
        }, -- end of ["point"]
        ["unitId"] = 2,
        ["skill"] = "High",
        ["unit"] = 
        {
            ["id_"] = 16783104,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 1,
        ["country"] = "USA",
        ["category"] = "helicopter",
        ["unitName"] = "AH-1s_1_2",
        ["groupName"] = "AH-1s_1",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 506.42102050781,
            ["x"] = -294670.375,
            ["z"] = 631863,
        }, -- end of ["pos"]
    }, -- end of [16783104]
    [16783616] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 639840,
            ["x"] = -294725.71428571,
        }, -- end of ["point"]
        ["unitId"] = 20,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16783616,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 11,
        ["country"] = "USA",
        ["category"] = "vehicle",
        ["unitName"] = "USTanks1_2",
        ["groupName"] = "USTanks1",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 7.6145420074463,
            ["x"] = -294725.71875,
            ["z"] = 639840,
        }, -- end of ["pos"]
    }, -- end of [16783616]
    [16784128] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 639920,
            ["x"] = -294805.71428571,
        }, -- end of ["point"]
        ["unitId"] = 22,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16784128,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 11,
        ["country"] = "USA",
        ["category"] = "vehicle",
        ["unitName"] = "USTanks1_4",
        ["groupName"] = "USTanks1",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 7.8300466537476,
            ["x"] = -294805.71875,
            ["z"] = 639920,
        }, -- end of ["pos"]
    }, -- end of [16784128]
    [16784640] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 653211.42857143,
            ["x"] = -293125.71428571,
        }, -- end of ["point"]
        ["unitId"] = 24,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16784640,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 12,
        ["country"] = "USA",
        ["category"] = "vehicle",
        ["unitName"] = "USTanks2_2",
        ["groupName"] = "USTanks2",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 19.774139404297,
            ["x"] = -293065,
            ["z"] = 653454.75,
        }, -- end of ["pos"]
    }, -- end of [16784640]
    [16785152] = 
    {
        ["type"] = "M-1 Abrams",
        ["point"] = 
        {
            ["y"] = 653291.42857143,
            ["x"] = -293205.71428571,
        }, -- end of ["point"]
        ["unitId"] = 26,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16785152,
        }, -- end of ["unit"]
        ["countryId"] = 11,
        ["groupId"] = 12,
        ["country"] = "USA",
        ["category"] = "vehicle",
        ["unitName"] = "USTanks2_4",
        ["groupName"] = "USTanks2",
        ["coalition"] = "blue",
        ["pos"] = 
        {
            ["y"] = 19.501737594604,
            ["x"] = -293069.34375,
            ["z"] = 653395.25,
        }, -- end of ["pos"]
    }, -- end of [16785152]
    [16777728] = 
    {
        ["type"] = "MOSCOW",
        ["point"] = 
        {
            ["y"] = 200000,
            ["x"] = -34285.714285714,
        }, -- end of ["point"]
        ["unitId"] = 15,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16777728,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 9,
        ["country"] = "Russia",
        ["category"] = "ship",
        ["unitName"] = "1ship1",
        ["groupName"] = "Rus Ships #1",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = -0.040012843906879,
            ["x"] = -34222.9375,
            ["z"] = 200000,
        }, -- end of ["pos"]
    }, -- end of [16777728]
    [16778240] = 
    {
        ["type"] = "MOSCOW",
        ["point"] = 
        {
            ["y"] = 73571.428571428,
            ["x"] = -86428.571428571,
        }, -- end of ["point"]
        ["unitId"] = 17,
        ["skill"] = "Average",
        ["unit"] = 
        {
            ["id_"] = 16778240,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 10,
        ["country"] = "Russia",
        ["category"] = "ship",
        ["unitName"] = "2ship1",
        ["groupName"] = "Rus Ships #2",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = -0.038739554584026,
            ["x"] = -86404.390625,
            ["z"] = 73629.3671875,
        }, -- end of ["pos"]
    }, -- end of [16778240]
    [16779264] = 
    {
        ["type"] = "Mi-8MT",
        ["point"] = 
        {
            ["y"] = 603285.71428571,
            ["x"] = -243285.71428571,
        }, -- end of ["point"]
        ["unitId"] = 5,
        ["skill"] = "Random",
        ["unit"] = 
        {
            ["id_"] = 16779264,
        }, -- end of ["unit"]
        ["countryId"] = 2,
        ["groupId"] = 3,
        ["country"] = "Russia",
        ["category"] = "helicopter",
        ["unitName"] = "Mi-8s_1_1",
        ["groupName"] = "Mi-8s_1",
        ["coalition"] = "red",
        ["pos"] = 
        {
            ["y"] = 500.54025268555,
            ["x"] = -246156.65625,
            ["z"] = 604966.5,
        }, -- end of ["pos"]
    }, -- end of [16779264]
} -- end of aliveUnits
