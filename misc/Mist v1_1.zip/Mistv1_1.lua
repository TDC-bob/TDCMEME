--[[
Mistv1_1
v010 change log
- fixed a bug with mist.addEventHandler

v009 changelog
- renamed mist.unitsInZonesByName to mist.getUnitsInZones
- renamed mist.getDeadMapObjsInZonesByName to mist.getDeadMapObjsInZones
- renamed mist.unitsInMovingZonesByName to mist.getUnitsInMovingZones
- renamed mist.unitsLOSByName to mist.getUnitsLOS
- renamed mist.mapobjs_dead_in_zones to mist.flagFunc.mapobjs_dead_zones
- renamed mist.mapobjs_dead_in_polygon_zone to mist.flagFunc.mapobjs_dead_polygon
- renamed mist.units_in_zones to mist.flagFunc.units_in_zones
- renamed mist.units_in_moving_zones to mist.flagFunc.units_in_moving_zones
- renamed mist.units_LOS to mist.flagFunc.units_LOS
- renamed mist.units_in_polygon_zone to mist.flagFunc.units_in_polygon
- mist.scheduleFunction now calls scheduled functions with pcall

- mist.getAttitude now accepts a Unit instead of a unit name
- mist.getHeading now accepts a Unit instead of a unit name 
- mist.getPitch now accepts a Unit instead of a unit name 
- mist.getRoll now accepts a Unit instead of a unit name
- mist.getYaw now accepts a Unit instead of a unit name
- mist.getAoA now accepts a Unit instead of a unit name
- mist.getClimbAngle now accepts a Unit instead of a unit name
- mist.demos.printAngles now accepts a Unit instead of a unit name 
- renamed mist.demos.printAngles to mist.demos.printFlightData
- mist.demos.printFlgihtData now additionally displays absolute velocity, absolute acceleration, Yaw plus AoA, transverse G loading, axial G loading, absolute G loading, energy, dE/dt
- added country, countryId, and coalition to the group level of the DBs.

- added energy, dE/dt, G loading 

- added mist.build, mist.majorVersion, mist.minorVersion
   - mist.build - the build version.  Increments every time changes are made and debugged.
   - mist.majorVersion - changes with publicly released major content additions
   - mist.minorVersion - changes with publicly released bug fixes/minor edits.

- added a "Mist version X.X.X loaded." message to dcs.log.

- FIXED A BUG WITH mist.scheduleFunction where functions with rep values would not run!!!!
- Adjusted timer.scheduleFunction in mist.main.
 
- mist.DBs.deadObjects should now behave properly when an object dies that has the same runtime id_ value of another object that has previously died (no longer uses the __newindex metatable event).
- mist.addEventHandler now returns an integer value for id, rather than accepts a variable for id (this makes it more like mist.scheduleFunction).
- mist.removeEventHandler now returns true or false
]]

--[[v008 changelog
- added mist.DBs.missionData   (database of basic mission information. Start time, theatre of war, and filenames saved within mission
- added mist.DBs.removedAliveUnits
- some debug messages commented out

- fixed? a bug with mist.DBs.dead_objects when trying to list dead players
	also, dead objects with duplicate runtime ids as a previous dead object will be indexed differently (as a string, such as "11454224 #1")
- fixed an oversight with mist.DBs.aliveUnits where units that were dead would be listed.

- renamed mist.schedule_function to mist.scheduleFunction
- renamed mist.remove_function to mist.removeFunction
- renamed mist.utils.deepcopy to mist.utils.deepCopy
- renamed mist.utils.TypeCheck to mist.utils.typeCheck
- renamed mist.utils.serialize_wcycles to mist.utils.serializeWithCycles
- renamed mist.utils.one_line_serialize to mist.utils.oneLineSerialize
- renamed mist.utils.tableshow to mist.utils.tableShow
- renamed mist.debug.write_data to mist.debug.writeData
- renamed mist.debug.dump_DBs to mist.debug.dumpDBs
- renamed mist.DBs.zones_by_name to mist.DBs.zonesByName
- renamed mist.DBs.zones_by_num to mist.DBs.zonesByNum
- renamed mist.DBs.NavPoints to mist.DBs.navPoints
- renamed mist.DBs.units_by_name to mist.DBs.unitsByName
- renamed mist.DBs.units_by_Id to mist.DBs.unitsById 
- renamed mist.DBs.units_by_cat to mist.DBs.unitsByCat
- renamed mist.DBs.units_by_num to mist.DBs.unitsByNum
- renamed mist.DBs.groups_by_name to mist.DBs.groupsByName
- renamed mist.DBs.groups_by_Id to mist.DBs.groupsById
- renamed mist.DBs.humans_by_name to mist.DBs.humansByName
- renamed mist.DBs.humans_by_Id to mist.DBs.humansById
- renamed mist.DBs.alive_units to mist.DBs.aliveUnits
- renamed mist.DBs.dead_objects to mist.DBs.deadObjects
- renamed mist.UnitsInZonesByName to mist.unitsInZonesByName
- renamed mist.UnitsInMovingZonesByName to mist.unitsInMovingZonesByName
- renamed mist.UnitsLOS to mist.unitsLOSByName

DB field name changes:
Unit -> unit
rt_id removed
Object -> object
ObjectType -> objectType
ObjectPos -> objectPos
ObjectData -> objectData
country_id -> countryId
unit_name -> unitName
group_name -> groupName
resources -> files
]]

--[[v007 change log
- added mist.DBs.zones_by_name  	(DB of trigger zones placed in editor, organized by name)
- added mist.DBs.zones_by_num		(DB of trigger zones placed in editor, in numerical order)
- added mist.DBs.NavPoints		(DB of Initial Points/nav points placed in editor, sorted by coalition)


- added mist.getDeadMapObjsInZonesByName
- added mist.getDeadMapObjsInPolygonZone 

- added mist.mapobjs_dead_in_zones
- added mist.mapobjs_dead_in_polygon_zone

]]

--[[ v006 change log
- added mist.units_in_polygon_zone
- added maxalt variable to mist.pointInPolygon  -- Code from http://softsurfer.com/Archive/algorithm_0103/algorithm_0103.htm
- fixed probable bug with stopflag conditions in trigger functions
- mist.units_in_zones now uses new type check function, so it needs to be re-tested.
- added mist.units_in_moving_zones
- fixed a bug with mist.getGroupPoints
- fixed a bug with mist.pointInPolygon

]]
--[[ v005 change log  (changes over uploaded v004:)

- Added mist.debug
- Added mist.debug.dump_DBs
- mist.utils.write_table renamed to mist.debug.write_data 
- mist.utils.dump_G renamed to mist.debug.dump_G
- error messages adjusted in mist.debug.dump_G and mist.debug.write_data

- mist.demos.printAngles now accepts unitname string input variable

- added mist.DBs.units_by_cat (units by category, such as ship, plane, vehicle, helicopter, static).  Inside each category, units indexed numerically.

- added mist.DBs.units_by_num - units, indexed numerically (BUT NOT BY unitId!).

- added mist.DBs.alive_units - indexed by runtime id_, contains all the alive units (not static objects) (same info as in the other DBs), 
  PLUS the alive unit's Unit object, and Pos3 position.  Updated no less frequently than once per second.
     
	 - added update_alive_units coroutine to populate this table.
	 - modified mist.main to run this coroutine.
	(NOTE TO SELF: May need to make an old_alive_units table too)

- mist.DBs.dead_objects table added- table of dead objects, indexed by runtime id_.  
	Example entries:
	mist.DBs.dead_objects = {
		[11553252] = {
			object = { id_ = 11553252 },
			objectType = 'vehicle',
			objectData = { ..... }, -- the same data contained in the alive_units entry for this vehicle
			Pos = {x = -562214.67543, y = 2243.4221, z = 1150221.54514 }, -- Position the vehicle died at.
		},
		[16231153] = {
			object = { id_ = 16231153 },
			objectType = 'static',
			objectData = { ..... }, -- the same data contained in the regular DBs for this static object
			Pos = {x = -6423121.23342, y = 152.1231, z = 1055212.331 }, --Position the static object died at.
		},
		[123555223] = {
			object = { id_ = 123555223 },
			objectType = 'building',
			Pos = {x = -505213.5532, y = 531.3365, z = 10733913.33214 }, --Position the map object died at
		},
		[21255292] = {
			object = { id_ = 21255292 },  -- object that could be be correlated to a unit, or a static object, and that getPosition failed on.
			objectType = 'unknown',
		},
	}
	
	- added default event handler to add objects to mist.dead_objects
	- modified __newindex metamethod for mist.DBs.dead_objects to derive dead object properites

]]
--MiST Mission Scripting Tools
mist = {}

-- don't change these
mist.majorVersion = 1
mist.minorVersion = 1
mist.build = 10 

--------------------------------------------------------------------------------------------------------------
-- the main area
do
	local coroutines = {}
	
	local function update_alive_units()  -- coroutine function
		local lalive_units = mist.DBs.aliveUnits -- local references for faster execution
		local lunits = mist.DBs.unitsByNum
		local ldeepcopy = mist.utils.deepCopy
		local lUnit = Unit
		local lremovedAliveUnits = mist.DBs.removedAliveUnits
		local updatedUnits = {}
		
		if #lunits > 0 then
			local units_per_run = math.ceil(#lunits/20)
			if units_per_run < 5 then
				units_per_run = 5
			end
			
			for i = 1, #lunits do
				if lunits[i].category ~= 'static' then -- can't get statics with Unit.getByName :(
					local unit = lUnit.getByName(lunits[i].unitName)
					if unit then
						--print('unit named ' .. lunits[i].unitName .. ' alive!')
						local pos = unit:getPosition()
						local newtbl = ldeepcopy(lunits[i])
						if pos then
							newtbl['pos'] = pos.p
						end
						newtbl['unit'] = unit
						--newtbl['rt_id'] = unit.id_
						lalive_units[unit.id_] = newtbl
						updatedUnits[unit.id_] = true
					end
				end
				if i%units_per_run == 0 then  
					--print('yielding at: ' .. tostring(i))
					coroutine.yield()
					--print('resuming at: ' .. tostring(i))
				end
			end
			-- All units updated, remove any "alive" units that were not updated- they are dead!
			for unit_id, unit in pairs(lalive_units) do
				if not updatedUnits[unit_id] then
					lremovedAliveUnits[unit_id] = unit
					lalive_units[unit_id] = nil
				end
			end
		end
	end
	local update_alive_units_counter = 0
	
	-- THE MAIN FUNCTION --   Accessed 100 times/sec.
	mist.main = function()
		timer.scheduleFunction(mist.main, {}, timer.getTime() + 0.01)  --reschedule first in case of Lua error
		----------------------------------------------------------------------------------------------------------
		--area to add new stuff in
		
		
		
		
		-----------------------------------------------------------------------------------------------------------
		--updating alive units
		update_alive_units_counter = update_alive_units_counter + 1
		if update_alive_units_counter == 5 then 
			update_alive_units_counter = 0
			
			if not coroutines.update_alive_units then
				coroutines['update_alive_units'] = coroutine.create(update_alive_units)
			end
			
			coroutine.resume(coroutines.update_alive_units)
			
			if coroutine.status(coroutines.update_alive_units) == 'dead' then
				coroutines.update_alive_units = nil
			end
		end
		
		mist.do_scheduled_functions()
	end -- end of mist.main
	
end
------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------
--Modified Slmod task scheduler, superior to timer.scheduleFunction
do
	local Tasks = {}
	local task_id = 0
	--[[ mist.scheduleFunction:
	int id = mist.schedule_task(f function, vars table, t number, rep number, st number)
	id - integer id of this function task
	f - function to run
	vars - table of vars for that function
	t - time to run function
	rep - time between repetitions of this function (OPTIONAL)
	st - time when repetitions of this function will stop automatically (OPTIONAL)
	]]
	mist.scheduleFunction = function(f, vars, t, rep, st)
		--verify correct types
		assert(type(f) == 'function', 'variable 1, expected function, got ' .. type(f))
		assert(type(vars) == 'table' or vars == nil, 'variable 2, expected table or nil, got ' .. type(f))
		assert(type(t) == 'number', 'variable 3, expected number, got ' .. type(t))
		assert(type(rep) == 'number' or rep == nil, 'variable 4, expected number or nil, got ' .. type(rep))
		assert(type(st) == 'number' or st == nil, 'variable 5, expected number or nil, got ' .. type(st))
		if not vars then
			vars = {}
		end
		task_id = task_id + 1
		table.insert(Tasks, {f = f, vars = vars, t = t, rep = rep, st = st, id = task_id})
		return task_id
	end
	
	-- removes a scheduled function based on the function's id.  returns true if successful, false if not successful.
	mist.removeFunction = function(id)
		for i = 1, #Tasks do
			if Tasks[i].id == id then
				table.remove(Tasks, i)
			end
		end
	end

	--------------------------------------------------------------------------------------------------------------------
	-- not intended for users to use this function.
	mist.do_scheduled_functions = function()
		local i = 1
		while i <= #Tasks do
			if not Tasks[i].rep then -- not a repeated process
				if Tasks[i].t <= timer.getTime() then 
					local Task = Tasks[i] -- local reference
					table.remove(Tasks, i)
					local err, errmsg = pcall(Task.f, unpack(Task.vars, 1, table.maxn(Task.vars)))
					if not err then
						print('mist.scheduleFunction, error in scheduled function: ' .. errmsg)
					end
					--Task.f(unpack(Task.vars, 1, table.maxn(Task.vars)))  -- do the task, do not increment i
				else
					i = i + 1
				end
			else
				if Tasks[i].st and Tasks[i].st <= timer.getTime() then   --if a stoptime was specified, and the stop time exceeded
					table.remove(Tasks, i) -- stop time exceeded, do not execute, do not increment i
				elseif Tasks[i].t <= timer.getTime() then
					local Task = Tasks[i] -- local reference
					Task.t = timer.getTime() + Task.rep  --schedule next run
					local err, errmsg = pcall(Task.f, unpack(Task.vars, 1, table.maxn(Task.vars)))
					if not err then
						print('mist.scheduleFunction, error in scheduled function: ' .. errmsg)
					end
					--Tasks[i].f(unpack(Tasks[i].vars, 1, table.maxn(Tasks[i].vars)))  -- do the task
					i = i + 1
				else
					i = i + 1
				end
			end
		end
	end

	
end
do
	local idNum = 0

	--Simplified event handler
	mist.addEventHandler = function(f) --id is optional!
		local handler = {}
		idNum = idNum + 1
		handler.id = idNum
		handler.f = f
		handler.onEvent = function(self, event)
			self.f(event)
		end
		world.addEventHandler(handler)
	end

	mist.removeEventHandler = function(id)
		for key, handler in pairs(world.eventHandlers) do
			if handler.id and handler.id == id then
				world.eventHandlers[key] = nil
				return true
			end
		end
		return false
	end

end
----------------------------------------------------------------------------------------------
-- Utils- conversion, Lua utils, etc.
mist.utils = {}

function mist.utils.makeVec2(Vec3)
	if Vec3.z then
		return {x = Vec3.x, y = Vec3.z}
	else
		return Vec3 -- NOT really a Vec3- could in fact be a Vec2 being erroneously given to function
	end
end

function mist.utils.makeVec3(Vec2, y)
	if not Vec2.z then
		if not y then
			y = 0
		end
		return {x = Vec2.x, y = y, z = Vec2.y}
	else
		return Vec2 -- z already existed! just return back same value
	end
end

mist.utils.toDegree = function(angle)
	return angle*180/math.pi
end

mist.utils.toRadian = function(angle)
	return angle*math.pi/180
end

--from http://lua-users.org/wiki/CopyTable
mist.utils.deepCopy = function(object)
	local lookup_table = {}
	local function _copy(object)
		if type(object) ~= "table" then
			return object
		elseif lookup_table[object] then
			return lookup_table[object]
		end
		local new_table = {}
		lookup_table[object] = new_table
		for index, value in pairs(object) do
			new_table[_copy(index)] = _copy(value)
		end
		return setmetatable(new_table, getmetatable(object))
	end
	return _copy(object)
end

-- From http://lua-users.org/wiki/SimpleRound
-- use negative idp for rounding ahead of decimal place, positive for rounding after decimal place
mist.utils.round = function(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

-- porting in Slmod's dostring
mist.utils.dostring = function(s)
	local f, err = loadstring(s)
	if f then
		return true, f()
	else
		return false, err
	end
end


--[[ mist.utils.typeCheck(fname, type_tbl, var_tbl)
Type-checking function:
Checks a var_tbl to a type_tbl.  Returns true if the var_tbl passes the type check, returns false plus an error message if the var_tbl fails.

type_tbl examples: 
type_tbl = { {'table', 'number'}, 'string', 'number', 'number', {'string', 'nil'}, {'number', 'nil'} } 
Compare to a var_tbl with up to six entries; var_tbl index 1 must be a table or a number; index 2, a string; index 3, a number;
index 4, a number; index 5, either a string or nil; and index 6, either a number or nil.

Another example:
type_tbl = { {'text', 'msg', 'text_out'} = 'string', display_time = 'number', display_mode = {'string', 'nil'} coa = {'string', 'nil'}}

var_tbl must have a string at one of the following table keys: "text", "msg", or "text_out".  var_tbl must have a number at table key "display_time", 
the table key "display_mode" must be either a string or nil, and the table key "coa" must be either a string or nil.
]]
function mist.utils.typeCheck(fname, type_tbl, var_tbl)
	
	for type_key, type_val in pairs(type_tbl) do
		--print('type_key:')
		--print(type_key)
		--print('type_val:')
		--print(type_val)
		
		--type_key can be a table of accepted keys- so try to find one that is not nil
		local type_key_str = ''
		local act_key = type_key -- actual key within var_tbl - necessary to use for multiple possible key variables.  Initialize to type_key
		if type(type_key) == 'table' then
	
			for i = 1, #type_key do
				if i ~= 1 then
					type_key_str = type_key_str .. '/'
				end
				type_key_str = type_key_str .. tostring(type_key[i])
				if var_tbl[type_key[i]] ~= nil then
					act_key = type_key[i]  -- found a non-nil entry, make act_key now this val.
				end
			end
		else
			type_key_str = tostring(type_key)
		end
		
		local err_msg = 'Error in function ' .. fname .. ', parameter "' .. type_key_str .. '", expected: '
		local passed_check = false
		
		if type(type_tbl[type_key]) == 'table' then
			--print('err_msg, before and after:')
			--print(err_msg)
			for j = 1, #type_tbl[type_key] do
				
				if j == 1 then
					err_msg = err_msg .. type_tbl[type_key][j]
				else
					err_msg = err_msg .. ' or ' .. type_tbl[type_key][j]
				end
				
				if type(var_tbl[act_key]) == type_tbl[type_key][j] then
					passed_check = true
				end
			end
			--print(err_msg)
		else
			--print('err_msg, before and after:')
			--print(err_msg)
			err_msg = err_msg .. type_tbl[type_key]
			--print(err_msg)
			if type(var_tbl[act_key]) == type_tbl[type_key] then
				passed_check = true
				
			end
			
		end
		
		if not passed_check then
			err_msg = err_msg .. ', got ' .. type(var_tbl[act_key])
			return false, err_msg
		end
	end
	return true
end

--porting in Slmod's "safestring" basic serialize
mist.utils.basicSerialize = function(s)
	if s == nil then
		return "\"\""
	else
		if ((type(s) == 'number') or (type(s) == 'boolean') or (type(s) == 'function') or (type(s) == 'table') or (type(s) == 'userdata') ) then
			return tostring(s)
		elseif type(s) == 'string' then
			s = string.format('%q', s)
			return s
		end
	end	
end

--porting in Slmod's serialize_slmod
mist.utils.serialize = function(name, value, level)
	-----Based on ED's serialize_simple2
	local basicSerialize = function (o)
	  if type(o) == "number" then
		return tostring(o)
	  elseif type(o) == "boolean" then
		return tostring(o)
	  else -- assume it is a string
		return mist.utils.basicSerialize(o)
	  end
	end
	
	local serialize_to_t = function (name, value, level)
	----Based on ED's serialize_simple2


	  local var_str_tbl = {}
	  if level == nil then level = "" end
	  if level ~= "" then level = level.."  " end
	  
	  table.insert(var_str_tbl, level .. name .. " = ")
	  
	  if type(value) == "number" or type(value) == "string" or type(value) == "boolean" then
		table.insert(var_str_tbl, basicSerialize(value) ..  ",\n")
	  elseif type(value) == "table" then
		  table.insert(var_str_tbl, "\n"..level.."{\n")
		  
		  for k,v in pairs(value) do -- serialize its fields
			local key
			if type(k) == "number" then
			  key = string.format("[%s]", k)
			else
			  key = string.format("[%q]", k)
			end

			table.insert(var_str_tbl, mist.utils.serialize(key, v, level.."  "))

		  end
		  if level == "" then
			table.insert(var_str_tbl, level.."} -- end of "..name.."\n")

		  else
			table.insert(var_str_tbl, level.."}, -- end of "..name.."\n")

		  end
	  else
		print("Cannot serialize a "..type(value))
	  end
	  return var_str_tbl
	end
	
	local t_str = serialize_to_t(name, value, level)
	
	return table.concat(t_str)
end

-- porting in slmod's serialize_wcycles
mist.utils.serializeWithCycles = function(name, value, saved)
	--mostly straight out of Programming in Lua
	local basicSerialize = function (o)
		if type(o) == "number" then
			return tostring(o)
		elseif type(o) == "boolean" then
			return tostring(o)
		else -- assume it is a string
			return mist.utils.basicSerialize(o)
		end
	end
	
	local t_str = {}
	saved = saved or {}       -- initial value
	if ((type(value) == 'string') or (type(value) == 'number') or (type(value) == 'table') or (type(value) == 'boolean')) then
		table.insert(t_str, name .. " = ")
		if type(value) == "number" or type(value) == "string" or type(value) == "boolean" then
			table.insert(t_str, basicSerialize(value) ..  "\n")
		else

			if saved[value] then    -- value already saved?
				table.insert(t_str, saved[value] .. "\n")
			else
				saved[value] = name   -- save name for next time
				table.insert(t_str, "{}\n")
				for k,v in pairs(value) do      -- save its fields
					local fieldname = string.format("%s[%s]", name, basicSerialize(k))
					table.insert(t_str, mist.utils.serializeWithCycles(fieldname, v, saved))
				end
			end
		end
		return table.concat(t_str)
	else
		return ""
	end
end

-- porting in Slmod's serialize_slmod2
mist.utils.oneLineSerialize = function(tbl)  -- serialization of a table all on a single line, no comments, made to replace old get_table_string function
	if type(tbl) == 'table' then --function only works for tables!

		local tbl_str = {}

		tbl_str[#tbl_str + 1] = '{ '
		
		for ind,val in pairs(tbl) do -- serialize its fields
			if type(ind) == "number" then
				tbl_str[#tbl_str + 1] = '[' 
				tbl_str[#tbl_str + 1] = tostring(ind)
				tbl_str[#tbl_str + 1] = '] = '
			else --must be a string
				tbl_str[#tbl_str + 1] = '[' 
				tbl_str[#tbl_str + 1] = mist.utils.basicSerialize(ind)
				tbl_str[#tbl_str + 1] = '] = '
			end
				
			if ((type(val) == 'number') or (type(val) == 'boolean')) then
				tbl_str[#tbl_str + 1] = tostring(val)
				tbl_str[#tbl_str + 1] = ', '		
			elseif type(val) == 'string' then
				tbl_str[#tbl_str + 1] = mist.utils.basicSerialize(val)
				tbl_str[#tbl_str + 1] = ', '
			elseif type(val) == 'nil' then -- won't ever happen, right?
				tbl_str[#tbl_str + 1] = 'nil, '
			elseif type(val) == 'table' then
				tbl_str[#tbl_str + 1] = mist.utils.oneLineSerialize(val)
				tbl_str[#tbl_str + 1] = ', '   --I think this is right, I just added it
			else
				print('unable to serialize value type ' .. mist.utils.basicSerialize(type(val)) .. ' at index ' .. tostring(ind))
			end
		
		end
		tbl_str[#tbl_str + 1] = '}'
		return table.concat(tbl_str)
	end
end

--Function to create string for viewing the contents of a table -NOT for serialization
mist.utils.tableShow = function(tbl, loc, indent, tableshow_tbls) --based on serialize_slmod, this is a _G serialization
	tableshow_tbls = tableshow_tbls or {} --create table of tables
	loc = loc or ""
	indent = indent or ""
	if type(tbl) == 'table' then --function only works for tables!
		tableshow_tbls[tbl] = loc
		
		local tbl_str = {}

		tbl_str[#tbl_str + 1] = indent .. '{\n'
		
		for ind,val in pairs(tbl) do -- serialize its fields
			if type(ind) == "number" then
				tbl_str[#tbl_str + 1] = indent 
				tbl_str[#tbl_str + 1] = loc .. '['
				tbl_str[#tbl_str + 1] = tostring(ind)
				tbl_str[#tbl_str + 1] = '] = '
			else
				tbl_str[#tbl_str + 1] = indent 
				tbl_str[#tbl_str + 1] = loc .. '['
				tbl_str[#tbl_str + 1] = mist.utils.basicSerialize(ind)
				tbl_str[#tbl_str + 1] = '] = '
			end
					
			if ((type(val) == 'number') or (type(val) == 'boolean')) then
				tbl_str[#tbl_str + 1] = tostring(val)
				tbl_str[#tbl_str + 1] = ',\n'		
			elseif type(val) == 'string' then
				tbl_str[#tbl_str + 1] = mist.utils.basicSerialize(val)
				tbl_str[#tbl_str + 1] = ',\n'
			elseif type(val) == 'nil' then -- won't ever happen, right?
				tbl_str[#tbl_str + 1] = 'nil,\n'
			elseif type(val) == 'table' then
				if tableshow_tbls[val] then
					tbl_str[#tbl_str + 1] = tostring(val) .. ' already defined: ' .. tableshow_tbls[val] .. ',\n'
				else
					tableshow_tbls[val] = loc ..  '[' .. mist.utils.basicSerialize(ind) .. ']'
					tbl_str[#tbl_str + 1] = tostring(val) .. ' '
					tbl_str[#tbl_str + 1] = mist.utils.tableShow(val,  loc .. '[' .. mist.utils.basicSerialize(ind).. ']', indent .. '    ', tableshow_tbls)
					tbl_str[#tbl_str + 1] = ',\n'  
				end
			elseif type(val) == 'function' then
				if debug and debug.getinfo then
					fcnname = tostring(val)
					local info = debug.getinfo(val, "S")
					if info.what == "C" then
						tbl_str[#tbl_str + 1] = string.format('%q', fcnname .. ', C function') .. ',\n'
					else 
						if (string.sub(info.source, 1, 2) == [[./]]) then
							tbl_str[#tbl_str + 1] = string.format('%q', fcnname .. ', defined in (' .. info.linedefined .. '-' .. info.lastlinedefined .. ')' .. info.source) ..',\n'
						else
							tbl_str[#tbl_str + 1] = string.format('%q', fcnname .. ', defined in (' .. info.linedefined .. '-' .. info.lastlinedefined .. ')') ..',\n'
						end
					end
					
				else
					tbl_str[#tbl_str + 1] = 'a function,\n'	
				end
			else
				tbl_str[#tbl_str + 1] = 'unable to serialize value type ' .. mist.utils.basicSerialize(type(val)) .. ' at index ' .. tostring(ind)
			end
		end
		
		tbl_str[#tbl_str + 1] = indent .. '}'
		return table.concat(tbl_str)
	end
end

mist.debug = {}

mist.debug.dump_G = function(fname)
	if lfs and io then
		local fdir = lfs.writedir() .. [[Logs\]] .. fname
		local f = io.open(fdir, 'w')
		f:write(mist.utils.tableShow(_G))
		f:close()
		local errmsg = 'mist.debug.dump_G wrote data to ' .. fdir
		print(errmsg)
		trigger.action.outText(errmsg, 10)
	else
		local errmsg = 'Error: insufficient libraries to run mist.debug.dump_G, you must disable the sanitization of the io and lfs libraries in ./Scripts/MissionScripting.lua'
		print(errmsg)
		trigger.action.outText(errmsg, 10)
	end
end

mist.debug.writeData = function(fcn, fcnVars, fname)
	if lfs and io then
		local fdir = lfs.writedir() .. [[Logs\]] .. fname
		local f = io.open(fdir, 'w')
		f:write(fcn(unpack(fcnVars, 1, table.maxn(fcnVars))))
		f:close()
		local errmsg = 'mist.debug.writeData wrote data to ' .. fdir
		print(errmsg)
		trigger.action.outText(errmsg, 10)
	else
		local errmsg = 'Error: insufficient libraries to run mist.debug.writeData, you must disable the sanitization of the io and lfs libraries in ./Scripts/MissionScripting.lua'
		print(errmsg)
		trigger.action.outText(errmsg, 10)
	end
end

mist.debug.dumpDBs = function()
	for DBname, DB in pairs(mist.DBs) do
		if type(DB) == 'table' and type(DBname) == 'string' then
			mist.debug.writeData(mist.utils.serialize, {DBname, DB}, 'mist_DBs_' .. DBname .. '.lua')
		end
	end
end

-----------------------------------------------------------------------------------------------------------------
--3D Vector manipulation
mist.vec = {}

mist.vec.add = function(vec1, vec2)
	return {x = vec1.x + vec2.x, y = vec1.y + vec2.y, z = vec1.z + vec2.z}
end

mist.vec.sub = function(vec1, vec2)
	return {x = vec1.x - vec2.x, y = vec1.y - vec2.y, z = vec1.z - vec2.z}
end

mist.vec.scalar_mult = function(vec, mult)
	return {x = vec.x*mult, y = vec.y*mult, z = vec.z*mult}
end

mist.vec.dp = function(vec1, vec2)
	return vec1.x*vec2.x + vec1.y*vec2.y + vec1.z*vec2.z
end

mist.vec.cp = function(vec1, vec2)
	return { x = vec1.y*vec2.z - vec1.z*vec2.y, y = vec1.z*vec2.x - vec1.x*vec2.z, z = vec1.x*vec2.y - vec1.y*vec2.x}
end

mist.vec.mag = function(vec)
	return (vec.x^2 + vec.y^2 + vec.z^2)^0.5
end
---------------------------------------------------------------------------------------------------------------------------

mist.getNorthCorrection = function(point)  --gets the correction needed for true north
	if not point.z then --Vec2; convert to Vec3
		point.z = point.y
		point.y = 0
	end
	local lat, lon = coord.LOtoLL(point)
	local north_posit = coord.LLtoLO(lat + 1, lon)
	return math.atan2(north_posit.z - point.z, north_posit.x - point.x)
end

function mist.getGroupPoints(groupname)   -- if groupname exists in env.mission, then returns table of the group's points in numerical order, such as: { [1] = {x = 299435.224, y = -1146632.6773}, [2] = { x = 663324.6563, y = 322424.1112}}
	for coa_name, coa_data in pairs(env.mission.coalition) do
		if coa_name == 'red' or coa_name == 'blue' and type(coa_data) == 'table' then			
			if coa_data.country then --there is a country table
				for cntry_id, cntry_data in pairs(coa_data.country) do
					for obj_type_name, obj_type_data in pairs(cntry_data) do
						if obj_type_name == "helicopter" or obj_type_name == "ship" or obj_type_name == "plane" or obj_type_name == "vehicle" then	-- only these types have points						
							if ((type(obj_type_data) == 'table') and obj_type_data.group and (type(obj_type_data.group) == 'table') and (#obj_type_data.group > 0)) then  --there's a group!				
								for group_num, group_data in pairs(obj_type_data.group) do		
									if group_data and group_data.name and group_data.name == groupname then -- this is the group we are looking for
										if group_data.route and group_data.route.points and #group_data.route.points > 0 then
											local points = {}
											for point_num, point in pairs(group_data.route.points) do
												if not point.point then
													points[point_num] = { x = point.x, y = point.y }
												else
													points[point_num] = point.point  --it's possible that the ME could move to the point = Vec2 notation.
												end
											end
											return points
										end
										return
									end  --if group_data and group_data.name and group_data.name == 'groupname'
								end --for group_num, group_data in pairs(obj_type_data.group) do		
							end --if ((type(obj_type_data) == 'table') and obj_type_data.group and (type(obj_type_data.group) == 'table') and (#obj_type_data.group > 0)) then	
						end --if obj_type_name == "helicopter" or obj_type_name == "ship" or obj_type_name == "plane" or obj_type_name == "vehicle" or obj_type_name == "static" then
					end --for obj_type_name, obj_type_data in pairs(cntry_data) do
				end --for cntry_id, cntry_data in pairs(coa_data.country) do
			end --if coa_data.country then --there is a country table
		end --if coa_name == 'red' or coa_name == 'blue' and type(coa_data) == 'table' then	
	end --for coa_name, coa_data in pairs(mission.coalition) do
end



--[[ table attitude = getAttitude(string unitname) -- will work on any unit, even if not an aircraft.

attitude = { 
	Heading = number, -- in radians, range of 0 to 2*pi, relative to true north
	Pitch = number, -- in radians, range of -pi/2 to pi/2
	Roll = number, -- in radians, range of 0 to 2*pi, right roll is positive direction
	
	--Yaw, AoA, ClimbAngle - relative to earth reference- DOES NOT TAKE INTO ACCOUNT WIND.
	Yaw = number, -- in radians, range of -pi to pi, right yaw is positive direction
	AoA = number, -- in radians, range of -pi to pi, rotation of aircraft to the right in comparison to flight direction being positive
	ClimbAngle = number, -- in radians, range of -pi/2 to pi/2
	
	--Maybe later?
	AxialVel = table, velocity of the aircraft transformed into directions of aircraft axes
	Speed = number -- absolute velocity in meters/sec

	} 

]]
function mist.getAttitude(unit)
	local unitpos = unit:getPosition()
	if unitpos then
		
		local Heading = math.atan2(unitpos.x.z, unitpos.x.x)
		
		Heading = Heading + mist.getNorthCorrection(unitpos.p)
		
		if Heading < 0 then
			Heading = Heading + 2*math.pi  -- put heading in range of 0 to 2*pi
		end
		---- heading complete.----
		
		local Pitch = math.asin(unitpos.x.y)
		---- pitch complete.----
		
		-- now get roll:
		--maybe not the best way to do it, but it works.
		
		--first, make a vector that is perpendicular to y and unitpos.x with cross product
		local cp = mist.vec.cp(unitpos.x, {x = 0, y = 1, z = 0})
		
		--now, get dot product of of this cross product with unitpos.z
		local dp = mist.vec.dp(cp, unitpos.z)
		
		--now get the magnitude of the roll (magnitude of the angle between two vectors is acos(vec1.vec2/|vec1||vec2|)
		local Roll = math.acos(dp/(mist.vec.mag(cp)*mist.vec.mag(unitpos.z)))

		--now, have to get sign of roll.
		-- by convention, making right roll positive
		-- to get sign of roll, use the y component of unitpos.z.  For right roll, y component is negative.
	   
		if unitpos.z.y > 0 then -- left roll, flip the sign of the roll
			Roll = -Roll
		end
		---- roll complete. ----
		
		--now, work on yaw, AoA, climb, and abs velocity
		local Yaw
		local AoA
		local ClimbAngle
		
		-- get unit velocity
		local unitvel = unit:getVelocity()
		if mist.vec.mag(unitvel) ~= 0 then --must have non-zero velocity!
			local AxialVel = {}  --unit velocity transformed into aircraft axes directions
			
			--transform velocity components in direction of aircraft axes.
			AxialVel.x = mist.vec.dp(unitpos.x, unitvel)  
			AxialVel.y = mist.vec.dp(unitpos.y, unitvel)
			AxialVel.z = mist.vec.dp(unitpos.z, unitvel)
			
			--Yaw is the angle between unitpos.x and the x and z velocities
			--define right yaw as positive
			Yaw = math.acos(mist.vec.dp({x = 1, y = 0, z = 0}, {x = AxialVel.x, y = 0, z = AxialVel.z})/mist.vec.mag({x = AxialVel.x, y = 0, z = AxialVel.z}))
			
			--now set correct direction:
			if AxialVel.z > 0 then
				Yaw = -Yaw
			end
			
			-- AoA is angle between unitpos.x and the x and y velocities
			AoA = math.acos(mist.vec.dp({x = 1, y = 0, z = 0}, {x = AxialVel.x, y = AxialVel.y, z = 0})/mist.vec.mag({x = AxialVel.x, y = AxialVel.y, z = 0}))
			
			--now set correct direction:
			if AxialVel.y > 0 then
				AoA = -AoA
			end
			
			ClimbAngle = math.asin(unitvel.y/mist.vec.mag(unitvel))
		end
		return { Heading = Heading, Pitch = Pitch, Roll = Roll, Yaw = Yaw, AoA = AoA, ClimbAngle = ClimbAngle}
	else
		print('unit:getPosition() is nil!')
	end
end

function mist.getHeading(unit)
	local unitpos = unit:getPosition()
	if unitpos then
		local Heading = math.atan2(unitpos.x.z, unitpos.x.x)
		
		Heading = Heading + mist.getNorthCorrection(unitpos.p)
		
		if Heading < 0 then
			Heading = Heading + 2*math.pi  -- put heading in range of 0 to 2*pi
		end
		return Heading
	end
end

function mist.getPitch(unit)
	local unitpos = unit:getPosition()
	if unitpos then
		return math.asin(unitpos.x.y)
	end
end

function mist.getRoll(unit)
	local unitpos = unit:getPosition()
	if unitpos then
		-- now get roll:
		--maybe not the best way to do it, but it works.
		
		--first, make a vector that is perpendicular to y and unitpos.x with cross product
		local cp = mist.vec.cp(unitpos.x, {x = 0, y = 1, z = 0})
		
		--now, get dot product of of this cross product with unitpos.z
		local dp = mist.vec.dp(cp, unitpos.z)
		
		--now get the magnitude of the roll (magnitude of the angle between two vectors is acos(vec1.vec2/|vec1||vec2|)
		local Roll = math.acos(dp/(mist.vec.mag(cp)*mist.vec.mag(unitpos.z)))

		--now, have to get sign of roll.
		-- by convention, making right roll positive
		-- to get sign of roll, use the y component of unitpos.z.  For right roll, y component is negative.
	   
		if unitpos.z.y > 0 then -- left roll, flip the sign of the roll
			Roll = -Roll
		end
		return Roll
	end
end

function mist.getYaw(unit)
	local unitpos = unit:getPosition()
	if unitpos then
		-- get unit velocity
		local unitvel = unit:getVelocity()
		if mist.vec.mag(unitvel) ~= 0 then --must have non-zero velocity!
			local AxialVel = {}  --unit velocity transformed into aircraft axes directions
			
			--transform velocity components in direction of aircraft axes.
			AxialVel.x = mist.vec.dp(unitpos.x, unitvel)  
			AxialVel.y = mist.vec.dp(unitpos.y, unitvel)
			AxialVel.z = mist.vec.dp(unitpos.z, unitvel)
			
			--Yaw is the angle between unitpos.x and the x and z velocities
			--define right yaw as positive
			local Yaw = math.acos(mist.vec.dp({x = 1, y = 0, z = 0}, {x = AxialVel.x, y = 0, z = AxialVel.z})/mist.vec.mag({x = AxialVel.x, y = 0, z = AxialVel.z}))
			
			--now set correct direction:
			if AxialVel.z > 0 then
				Yaw = -Yaw
			end
			return Yaw	
		end
	end
end

function mist.getAoA(unit)
	local unitpos = unit:getPosition()
	if unitpos then
		local unitvel = unit:getVelocity()
		if mist.vec.mag(unitvel) ~= 0 then --must have non-zero velocity!
			local AxialVel = {}  --unit velocity transformed into aircraft axes directions
			
			--transform velocity components in direction of aircraft axes.
			AxialVel.x = mist.vec.dp(unitpos.x, unitvel)  
			AxialVel.y = mist.vec.dp(unitpos.y, unitvel)
			AxialVel.z = mist.vec.dp(unitpos.z, unitvel)
			
			-- AoA is angle between unitpos.x and the x and y velocities
			local AoA = math.acos(mist.vec.dp({x = 1, y = 0, z = 0}, {x = AxialVel.x, y = AxialVel.y, z = 0})/mist.vec.mag({x = AxialVel.x, y = AxialVel.y, z = 0}))
			
			--now set correct direction:
			if AxialVel.y > 0 then
				AoA = -AoA
			end
			return AoA
		end
	end
end

function mist.getClimbAngle(unit)
	local unitpos = unit:getPosition()
	if unitpos then
		local unitvel = unit:getVelocity()
		if mist.vec.mag(unitvel) ~= 0 then --must have non-zero velocity!
			return math.asin(unitvel.y/mist.vec.mag(unitvel))
		end
	end
end
-----------------------------------------------------------------------------------------------------------
-- Database building
mist.DBs = {}

mist.DBs.missionData = {}
-----------------------------------------
if env.mission then 
	
	mist.DBs.missionData['startTime'] = env.mission.start_time
	mist.DBs.missionData['theatre'] = env.mission.theatre
	mist.DBs.missionData['version'] = env.mission.version
	mist.DBs.missionData['files'] = {}
	if type(env.mission.resourceCounter) == 'table' then
		for fIndex, fData in pairs (env.mission.resourceCounter) do
			mist.DBs.missionData.files[#mist.DBs.missionData.files + 1] =  mist.utils.deepCopy(fIndex)
		end
	end
	mist.DBs.missionData['bullseye'] = {['red'] = {}, ['blue'] = {}} -- if we add more coalition specific data then bullsye should be categorized by coaliton. For now its just the bullseye table
	mist.DBs.missionData.bullseye.red['x'] = env.mission.coalition.red.bullseye.x --should it be point.x?
	mist.DBs.missionData.bullseye.red['y'] = env.mission.coalition.red.bullseye.y
	mist.DBs.missionData.bullseye.blue['x'] = env.mission.coalition.blue.bullseye.x
	mist.DBs.missionData.bullseye.blue['y'] = env.mission.coalition.blue.bullseye.y
	
end

----------------------------------------

mist.DBs.zonesByName = {}
mist.DBs.zonesByNum = {}


if env.mission.triggers and env.mission.triggers.zones then
	for zone_ind, zone_data in pairs(env.mission.triggers.zones) do
		if type(zone_data) == 'table' then
			local zone = mist.utils.deepCopy(zone_data)
			zone['point'] = {}  -- point is used by SSE
			zone['point']['x'] = zone_data.x
			zone['point']['y'] = 0
			zone['point']['z'] = zone_data.y
			
			mist.DBs.zonesByName[zone_data.name] = zone
			mist.DBs.zonesByNum[#mist.DBs.zonesByNum + 1] = mist.utils.deepCopy(zone)  --[[deepcopy so that the zone in zones_by_name and the zone in
																								zones_by_num se are different objects.. don't want them linked.]]
		end
	end
end

mist.DBs.navPoints = {}
mist.DBs.units = {}
 --Build mist.db.units and mist.DBs.navPoints
for coa_name, coa_data in pairs(env.mission.coalition) do

	if coa_name == 'red' or coa_name == 'blue' and type(coa_data) == 'table' then
		mist.DBs.units[coa_name] = {}
		
		----------------------------------------------
		-- build nav points DB
		mist.DBs.navPoints[coa_name] = {}
		if coa_data.nav_points then --navpoints
			--mist.debug.writeData (mist.utils.serialize,{'NavPoints',coa_data.nav_points}, 'NavPoints.txt')
			for nav_ind, nav_data in pairs(coa_data.nav_points) do
				
				if type(nav_data) == 'table' then
					mist.DBs.navPoints[coa_name][nav_ind] = mist.utils.deepCopy(nav_data)

					mist.DBs.navPoints[coa_name][nav_ind]['name'] = nav_data.callsignStr  -- name is a little bit more self-explanatory.
					mist.DBs.navPoints[coa_name][nav_ind]['point'] = {}  -- point is used by SSE, support it.
					mist.DBs.navPoints[coa_name][nav_ind]['point']['x'] = nav_data.x
					mist.DBs.navPoints[coa_name][nav_ind]['point']['y'] = 0
					mist.DBs.navPoints[coa_name][nav_ind]['point']['z'] = nav_data.y
				end
			end
		end
		-------------------------------------------------		
		if coa_data.country then --there is a country table
			for cntry_id, cntry_data in pairs(coa_data.country) do
				
				mist.DBs.units[coa_name][cntry_data.name] = {}
				mist.DBs.units[coa_name][cntry_data.name]["countryId"] = cntry_id

				if type(cntry_data) == 'table' then  --just making sure
				
					for obj_type_name, obj_type_data in pairs(cntry_data) do
					
						if obj_type_name == "helicopter" or obj_type_name == "ship" or obj_type_name == "plane" or obj_type_name == "vehicle" or obj_type_name == "static" then --should be an unncessary check 
							
							local category = obj_type_name
							
							if ((type(obj_type_data) == 'table') and obj_type_data.group and (type(obj_type_data.group) == 'table') and (#obj_type_data.group > 0)) then  --there's a group!
							
								mist.DBs.units[coa_name][cntry_data.name][category] = {}
								
								for group_num, group_data in pairs(obj_type_data.group) do
									
									if group_data and group_data.units and type(group_data.units) == 'table' then  --making sure again- this is a valid group
											
										mist.DBs.units[coa_name][cntry_data.name][category][group_num] = {}
										mist.DBs.units[coa_name][cntry_data.name][category][group_num]["groupName"] = group_data.name
										mist.DBs.units[coa_name][cntry_data.name][category][group_num]["groupId"] = group_data.groupId	
										mist.DBs.units[coa_name][cntry_data.name][category][group_num]["category"] = category
										mist.DBs.units[coa_name][cntry_data.name][category][group_num]["coalition"] = coa_name
										mist.DBs.units[coa_name][cntry_data.name][category][group_num]["country"] = cntry_data.name
										mist.DBs.units[coa_name][cntry_data.name][category][group_num]["countryId"] = cntry_id
										mist.DBs.units[coa_name][cntry_data.name][category][group_num]["units"] = {}
															
										for unit_num, unit_data in pairs(group_data.units) do
											local units_tbl = mist.DBs.units[coa_name][cntry_data.name][category][group_num]["units"]  --pointer to the units table for this group
											
											units_tbl[unit_num] = {}
											units_tbl[unit_num]["unitName"] = unit_data.name
											units_tbl[unit_num]["type"] = unit_data.type
											units_tbl[unit_num]["skill"] = unit_data.skill  --will be nil for statics
											units_tbl[unit_num]["unitId"] = unit_data.unitId
											units_tbl[unit_num]["category"] = category
											units_tbl[unit_num]["coalition"] = coa_name
											units_tbl[unit_num]["country"] = cntry_data.name
											units_tbl[unit_num]["countryId"] = cntry_id
											
											if unit_data.point then  --ME currently does not work like this, but it might one day
												units_tbl[unit_num]["point"] = unit_data.point
											else
												units_tbl[unit_num]["point"] = {}
												units_tbl[unit_num]["point"]["x"] = unit_data.x
												units_tbl[unit_num]["point"]["y"] = unit_data.y
											end
											
											units_tbl[unit_num]["groupName"] = group_data.name
											units_tbl[unit_num]["groupId"] = group_data.groupId
										end --for unit_num, unit_data in pairs(group_data.units) do
									end --if group_data and group_data.units then
								end --for group_num, group_data in pairs(obj_type_data.group) do
							end --if ((type(obj_type_data) == 'table') and obj_type_data.group and (type(obj_type_data.group) == 'table') and (#obj_type_data.group > 0)) then
						end --if obj_type_name == "helicopter" or obj_type_name == "ship" or obj_type_name == "plane" or obj_type_name == "vehicle" or obj_type_name == "static" then
					end --for obj_type_name, obj_type_data in pairs(cntry_data) do
				end --if type(cntry_data) == 'table' then
			end --for cntry_id, cntry_data in pairs(coa_data.country) do
		end --if coa_data.country then --there is a country table
	end --if coa_name == 'red' or coa_name == 'blue' and type(coa_data) == 'table' then
end --for coa_name, coa_data in pairs(mission.coalition) do

mist.DBs.unitsByName = {}
mist.DBs.unitsById = {}
mist.DBs.unitsByCat = {}

mist.DBs.unitsByCat['helicopter'] = {}  -- adding default categories
mist.DBs.unitsByCat['plane'] = {}
mist.DBs.unitsByCat['ship'] = {}
mist.DBs.unitsByCat['static'] = {}
mist.DBs.unitsByCat['vehicle'] = {}

mist.DBs.unitsByNum = {}

mist.DBs.groupsByName = {}
mist.DBs.groupsById = {}
mist.DBs.humansByName = {}
mist.DBs.humansById = {}

mist.DBs.aliveUnits = {}  -- will be filled in by the "update_alive_units" coroutine in mist.main.

mist.DBs.removedAliveUnits = {} -- will be filled in by the "update_alive_units" coroutine in mist.main.
-- create mist.DBs.oldAliveUnits
-- do
	-- local intermediate_alive_units = {}  -- between 0 and 0.5 secs old
	-- local function make_old_alive_units() -- called every 0.5 secs, makes the old_alive_units DB which is just a copy of alive_units that is 0.5 to 1 sec old
		-- if intermediate_alive_units then 
			-- mist.DBs.oldAliveUnits = mist.utils.deepCopy(intermediate_alive_units)
		-- end
		-- intermediate_alive_units = mist.utils.deepCopy(mist.DBs.aliveUnits) 
		-- timer.scheduleFunction(make_old_alive_units, nil, timer.getTime() + 0.5) 
	-- end
	
	-- make_old_alive_units()
-- end


--Build DBs
for coa_name, coa_data in pairs(mist.DBs.units) do
	for cntry_name, cntry_data in pairs(coa_data) do
		for category_name, category_data in pairs(cntry_data) do
			if type(category_data) == 'table' then
				for group_ind, group_data in pairs(category_data) do
					if type(group_data) == 'table' and group_data.units and type(group_data.units) == 'table' and #group_data.units > 0 then  -- OCD paradigm programming
						mist.DBs.groupsByName[group_data.groupName] = mist.utils.deepCopy(group_data)
						mist.DBs.groupsById[group_data.groupId] = mist.utils.deepCopy(group_data)
						for unit_ind, unit_data in pairs(group_data.units) do
							mist.DBs.unitsByName[unit_data.unitName] = mist.utils.deepCopy(unit_data)
							mist.DBs.unitsById[unit_data.unitId] = mist.utils.deepCopy(unit_data)
			
							mist.DBs.unitsByCat[unit_data.category] = mist.DBs.unitsByCat[unit_data.category] or {} -- future-proofing against new categories...
							table.insert(mist.DBs.unitsByCat[unit_data.category], mist.utils.deepCopy(unit_data))
							--print('inserting ' .. unit_data.unitName)
							table.insert(mist.DBs.unitsByNum, mist.utils.deepCopy(unit_data))
							
							if unit_data.skill and (unit_data.skill == "Client" or unit_data.skill == "Player") then
								mist.DBs.humansByName[unit_data.unitName] = mist.utils.deepCopy(unit_data)
								mist.DBs.humansById[unit_data.unitId] = mist.utils.deepCopy(unit_data)
							end
						end
					end
				end
			end
		end
	end
end


mist.DBs.deadObjects = {}

do
	local mt = {}
	
	mt.__newindex = function(t, key, val)
		---------------------------------------------------------------
		local original_key = key --only for duplicate runtime IDs.
		local key_ind = 1
		while mist.DBs.deadObjects[key] do
			--print('duplicate runtime id of previously dead object- key: ' .. tostring(key))
			key = tostring(original_key) .. ' #' .. tostring(key_ind)
			key_ind = key_ind + 1
		end
		---------------------------------------------------------------
		
		if mist.DBs.aliveUnits and mist.DBs.aliveUnits[val.object.id_] then
			--print('object found in alive_units')
			val['objectData'] = mist.utils.deepCopy(mist.DBs.aliveUnits[val.object.id_])
			local pos = Object.getPosition(val.object)
			if pos then
				val['objectPos'] = pos.p
			end
			val['objectType'] = mist.DBs.aliveUnits[val.object.id_].category
		
		elseif mist.DBs.removedAliveUnits and mist.DBs.removedAliveUnits[val.object.id_] then  -- it didn't exist in alive_units, check old_alive_units
			--print('object found in old_alive_units')
			val['objectData'] = mist.utils.deepCopy(mist.DBs.removedAliveUnits[val.object.id_])
			local pos = Object.getPosition(val.object)
			if pos then
				val['objectPos'] = pos.p
			end
			val['objectType'] = mist.DBs.removedAliveUnits[val.object.id_].category
			
		else  --attempt to determine if static object...
			--print('object not found in alive units or old alive units')
			local pos = Object.getPosition(val.object)
			if pos then
				local static_found = false
				for ind, static in pairs(mist.DBs.unitsByCat['static']) do
					if ((pos.p.x - static.point.x)^2 + (pos.p.z - static.point.y)^2)^0.5 < 0.1 then --really, it should be zero...
						--print('correlated dead static object to position')
						val['objectData'] = static
						val['objectPos'] = pos.p
						val['objectType'] = 'static'
						static_found = true
						break
					end
				end
				if not static_found then
					val['objectPos'] = pos.p
					val['objectType'] = 'building'
				end
			else
				val['objectType'] = 'unknown'
			end
		end
		rawset(t, key, val)
	end

	setmetatable(mist.DBs.deadObjects, mt)
end

-- Event handler to start creating the dead_objects table
do 

	local function addDeadObject(event)
		if event.id == world.event.S_EVENT_DEAD or event.id == world.event.S_EVENT_CRASH then
			if event.initiator and event.initiator.id_ and event.initiator.id_ > 0 then
			
				local id = event.initiator.id_  -- initial ID, could change if there is a duplicate id_ already dead.
				local val = {object = event.initiator} -- the new entry in mist.DBs.deadObjects.
				
				---------------------------------------------------------------
				local original_id = id  --only for duplicate runtime IDs.
				local id_ind = 1
				while mist.DBs.deadObjects[id] do
					--print('duplicate runtime id of previously dead object- id: ' .. tostring(id))
					id = tostring(original_id) .. ' #' .. tostring(id_ind)
					id_ind = id_ind + 1
				end
				---------------------------------------------------------------
				
				if mist.DBs.aliveUnits and mist.DBs.aliveUnits[val.object.id_] then
					--print('object found in alive_units')
					val['objectData'] = mist.utils.deepCopy(mist.DBs.aliveUnits[val.object.id_])
					local pos = Object.getPosition(val.object)
					if pos then
						val['objectPos'] = pos.p
					end
					val['objectType'] = mist.DBs.aliveUnits[val.object.id_].category
				
				elseif mist.DBs.removedAliveUnits and mist.DBs.removedAliveUnits[val.object.id_] then  -- it didn't exist in alive_units, check old_alive_units
					--print('object found in old_alive_units')
					val['objectData'] = mist.utils.deepCopy(mist.DBs.removedAliveUnits[val.object.id_])
					local pos = Object.getPosition(val.object)
					if pos then
						val['objectPos'] = pos.p
					end
					val['objectType'] = mist.DBs.removedAliveUnits[val.object.id_].category
					
				else  --attempt to determine if static object...
					--print('object not found in alive units or old alive units')
					local pos = Object.getPosition(val.object)
					if pos then
						local static_found = false
						for ind, static in pairs(mist.DBs.unitsByCat['static']) do
							if ((pos.p.x - static.point.x)^2 + (pos.p.z - static.point.y)^2)^0.5 < 0.1 then --really, it should be zero...
								--print('correlated dead static object to position')
								val['objectData'] = static
								val['objectPos'] = pos.p
								val['objectType'] = 'static'
								static_found = true
								break
							end
						end
						if not static_found then
							val['objectPos'] = pos.p
							val['objectType'] = 'building'
						end
					else
						val['objectType'] = 'unknown'
					end
				end
				mist.DBs.deadObjects[id] = val

			end
		end
	end

	
	mist.addEventHandler(addDeadObject)
	
end





function mist.makeUnitTable(tbl)
--[[
Prefixes:
"[-u]<unit name>" - subtract this unit if its in the table
"[g]<group name>" - add this group to the table
"[-g]<group name>" - subtract this group from the table
"[c]<country name>"  - add this country's units
"[-c]<country name>" - subtract this country's units if any are in the table

Stand-alone identifiers
"[all]" - add all units
"[-all]" - subtract all units (not very useful by itself)
"[blue]" - add all blue units
"[-blue]" - subtract all blue units
"[red]" - add all red coalition units
"[-red]" - subtract all red units

Compound Identifiers:
"[c][helicopter]<country name>"  - add all of this country's helicopters
"[-c][helicopter]<country name>" - subtract all of this country's helicopters
"[c][plane]<country name>"  - add all of this country's planes
"[-c][plane]<country name>" - subtract all of this country's planes
"[c][ship]<country name>"  - add all of this country's ships
"[-c][ship]<country name>" - subtract all of this country's ships
"[c][vehicle]<country name>"  - add all of this country's vehicles
"[-c][vehicle]<country name>" - subtract all of this country's vehicles

"[all][helicopter]" -  add all helicopters
"[-all][helicopter]" - subtract all helicopters
"[all][plane]" - add all  planes
"[-all][plane]" - subtract all planes
"[all][ship]" - add all ships
"[-all][ship]" - subtract all ships
"[all][vehicle]" - add all vehicles
"[-all][vehicle]" - subtract all vehicles

"[blue][helicopter]" -  add all blue coalition helicopters
"[-blue][helicopter]" - subtract all blue coalition helicopters
"[blue][plane]" - add all blue coalition planes
"[-blue][plane]" - subtract all blue coalition planes
"[blue][ship]" - add all blue coalition ships
"[-blue][ship]" - subtract all blue coalition ships
"[blue][vehicle]" - add all blue coalition vehicles
"[-blue][vehicle]" - subtract all blue coalition vehicles

"[red][helicopter]" -  add all red coalition helicopters
"[-red][helicopter]" - subtract all red coalition helicopters
"[red][plane]" - add all red coalition planes
"[-red][plane]" - subtract all red coalition planes
"[red][ship]" - add all red coalition ships
"[-red][ship]" - subtract all red coalition ships
"[red][vehicle]" - add all red coalition vehicles
"[-red][vehicle]" - subtract all red coalition vehicles


Country names to be used in [c] and [-c] short-cuts:
"Turkey" 
"Norway"
"The Netherlands"
"Spain"
"UK"
"Denmark"
"USA"
"Georgia"
"Germany"
"Belgium"
"Canada"
"France"
"Israel"
"Ukraine"
"Russia"
"South Osetia"
"Abkhazia"
"Italy"
]]

	--Assumption: will be passed a table of strings, sequential
	local units_by_name = {}

	local l_munits = mist.DBs.units  --local reference for faster execution
	for i = 1, #tbl do
		local unit = tbl[i]
		if unit:sub(1,4) == '[-u]' then --subtract a unit
			if units_by_name[unit:sub(5)] then -- 5 to end
				units_by_name[unit:sub(5)] = nil  --remove
			end
		elseif unit:sub(1,3) == '[g]' then -- add a group
			for coa, coa_tbl in pairs(l_munits) do
				for country, country_table in pairs(coa_tbl) do
					for unit_type, unit_type_tbl in pairs(country_table) do
						if type(unit_type_tbl) == 'table' then 
							for group_ind, group_tbl in pairs(unit_type_tbl) do
								if type(group_tbl) == 'table' and group_tbl.groupName == unit:sub(4) then -- index 4 to end
									for unit_ind, unit in pairs(group_tbl.units) do
										units_by_name[unit.unitName] = true  --add	
									end
								end
							end
						end
					end
				end
			end
		elseif unit:sub(1,4) == '[-g]' then -- subtract a group
			for coa, coa_tbl in pairs(l_munits) do
				for country, country_table in pairs(coa_tbl) do
					for unit_type, unit_type_tbl in pairs(country_table) do
						if type(unit_type_tbl) == 'table' then 
							for group_ind, group_tbl in pairs(unit_type_tbl) do
								if type(group_tbl) == 'table' and group_tbl.groupName == unit:sub(5) then -- index 5 to end
									for unit_ind, unit in pairs(group_tbl.units) do
										if units_by_name[unit.unitName] then
											units_by_name[unit.unitName] = nil --remove
										end
									end
								end
							end
						end
					end
				end
			end
		elseif unit:sub(1,3) == '[c]' then -- add a country
			local category = ''
			local country_start = 4
			if unit:sub(4,15) == '[helicopter]' then 
				category = 'helicopter'
				country_start = 16
			elseif unit:sub(4,10) == '[plane]' then 
				category = 'plane'
				country_start = 11
			elseif unit:sub(4,9) == '[ship]' then 
				category = 'ship'
				country_start = 10
			elseif unit:sub(4,12) == '[vehicle]' then 
				category = 'vehicle'
				country_start = 13
			end	
			for coa, coa_tbl in pairs(l_munits) do
				for country, country_table in pairs(coa_tbl) do
					if country == unit:sub(country_start) then   -- match
						for unit_type, unit_type_tbl in pairs(country_table) do
							if type(unit_type_tbl) == 'table' and (category == '' or unit_type == category) then 
								for group_ind, group_tbl in pairs(unit_type_tbl) do
									if type(group_tbl) == 'table' then
										for unit_ind, unit in pairs(group_tbl.units) do
											units_by_name[unit.unitName] = true  --add	
										end
									end
								end
							end
						end
					end
				end
			end
		elseif unit:sub(1,4) == '[-c]' then -- subtract a country
			local category = ''
			local country_start = 5
			if unit:sub(5,16) == '[helicopter]' then 
				category = 'helicopter'
				country_start = 17
			elseif unit:sub(5,11) == '[plane]' then 
				category = 'plane'
				country_start = 12
			elseif unit:sub(5,10) == '[ship]' then 
				category = 'ship'
				country_start = 11
			elseif unit:sub(5,13) == '[vehicle]' then 
				category = 'vehicle'
				country_start = 14
			end	
			for coa, coa_tbl in pairs(l_munits) do
				for country, country_table in pairs(coa_tbl) do
					if country == unit:sub(country_start) then   -- match
						for unit_type, unit_type_tbl in pairs(country_table) do
							if type(unit_type_tbl) == 'table' and (category == '' or unit_type == category) then 
								for group_ind, group_tbl in pairs(unit_type_tbl) do
									if type(group_tbl) == 'table' then 
										for unit_ind, unit in pairs(group_tbl.units) do
											if units_by_name[unit.unitName] then
												units_by_name[unit.unitName] = nil  --remove
											end
										end
									end
								end
							end
						end
					end
				end
			end
		elseif unit:sub(1,6) ==  '[blue]' then -- add blue coalition
			local category = ''
			if unit:sub(7) == '[helicopter]' then 
				category = 'helicopter'
			elseif unit:sub(7) == '[plane]' then 
				category = 'plane'
			elseif unit:sub(7) == '[ship]' then 
				category = 'ship'
			elseif unit:sub(7) == '[vehicle]' then 
				category = 'vehicle'
			end	
			for coa, coa_tbl in pairs(l_munits) do
				if coa == 'blue' then
					for country, country_table in pairs(coa_tbl) do
						for unit_type, unit_type_tbl in pairs(country_table) do
							if type(unit_type_tbl) == 'table' and (category == '' or unit_type == category) then 
								for group_ind, group_tbl in pairs(unit_type_tbl) do
									if type(group_tbl) == 'table' then
										for unit_ind, unit in pairs(group_tbl.units) do
											units_by_name[unit.unitName] = true  --add										
										end
									end
								end
							end
						end
					end
				end
			end	
		elseif unit:sub(1,7) == '[-blue]' then -- subtract blue coalition
			local category = ''
			if unit:sub(8) == '[helicopter]' then 
				category = 'helicopter'
			elseif unit:sub(8) == '[plane]' then 
				category = 'plane'
			elseif unit:sub(8) == '[ship]' then 
				category = 'ship'
			elseif unit:sub(8) == '[vehicle]' then 
				category = 'vehicle'
			end	
			for coa, coa_tbl in pairs(l_munits) do
				if coa == 'blue' then
					for country, country_table in pairs(coa_tbl) do
						for unit_type, unit_type_tbl in pairs(country_table) do
							if type(unit_type_tbl) == 'table' and (category == '' or unit_type == category) then  
								for group_ind, group_tbl in pairs(unit_type_tbl) do
									if type(group_tbl) == 'table' then
										for unit_ind, unit in pairs(group_tbl.units) do
											if units_by_name[unit.unitName] then
												units_by_name[unit.unitName] = nil  --remove
											end
										end
									end
								end
							end
						end
					end
				end
			end	
		elseif unit:sub(1,5) == '[red]' then -- add red coalition
			local category = ''
			if unit:sub(6) == '[helicopter]' then 
				category = 'helicopter'
			elseif unit:sub(6) == '[plane]' then 
				category = 'plane'
			elseif unit:sub(6) == '[ship]' then 
				category = 'ship'
			elseif unit:sub(6) == '[vehicle]' then 
				category = 'vehicle'
			end	
			for coa, coa_tbl in pairs(l_munits) do
				if coa == 'red' then
					for country, country_table in pairs(coa_tbl) do
						for unit_type, unit_type_tbl in pairs(country_table) do
							if type(unit_type_tbl) == 'table' and (category == '' or unit_type == category) then  
								for group_ind, group_tbl in pairs(unit_type_tbl) do
									if type(group_tbl) == 'table' then
										for unit_ind, unit in pairs(group_tbl.units) do
											units_by_name[unit.unitName] = true  --add									
										end
									end
								end
							end
						end
					end
				end
			end
		elseif unit:sub(1,6) == '[-red]' then -- subtract red coalition
			local category = ''
			if unit:sub(7) == '[helicopter]' then 
				category = 'helicopter'
			elseif unit:sub(7) == '[plane]' then 
				category = 'plane'
			elseif unit:sub(7) == '[ship]' then 
				category = 'ship'
			elseif unit:sub(7) == '[vehicle]' then 
				category = 'vehicle'
			end	
			for coa, coa_tbl in pairs(l_munits) do
				if coa == 'red' then
					for country, country_table in pairs(coa_tbl) do
						for unit_type, unit_type_tbl in pairs(country_table) do
							if type(unit_type_tbl) == 'table' and (category == '' or unit_type == category) then  
								for group_ind, group_tbl in pairs(unit_type_tbl) do
									if type(group_tbl) == 'table' then
										for unit_ind, unit in pairs(group_tbl.units) do
											if units_by_name[unit.unitName] then
												units_by_name[unit.unitName] = nil  --remove
											end
										end
									end
								end
							end
						end
					end
				end
			end	
		elseif unit:sub(1,5) == '[all]' then -- add all of a certain category (or all categories)
			local category = ''
			if unit:sub(6) == '[helicopter]' then 
				category = 'helicopter'
			elseif unit:sub(6) == '[plane]' then 
				category = 'plane'
			elseif unit:sub(6) == '[ship]' then 
				category = 'ship'
			elseif unit:sub(6) == '[vehicle]' then 
				category = 'vehicle'
			end	
			for coa, coa_tbl in pairs(l_munits) do
				for country, country_table in pairs(coa_tbl) do
					for unit_type, unit_type_tbl in pairs(country_table) do
						if type(unit_type_tbl) == 'table' and (category == '' or unit_type == category) then  
							for group_ind, group_tbl in pairs(unit_type_tbl) do
								if type(group_tbl) == 'table' then
									for unit_ind, unit in pairs(group_tbl.units) do
										units_by_name[unit.unitName] = true  --add										
									end
								end
							end
						end
					end
				end
			end
		elseif unit:sub(1,6) == '[-all]' then -- subtract all of a certain category (or all categories)
			local category = ''
			if unit:sub(7) == '[helicopter]' then 
				category = 'helicopter'
			elseif unit:sub(7) == '[plane]' then 
				category = 'plane'
			elseif unit:sub(7) == '[ship]' then 
				category = 'ship'
			elseif unit:sub(7) == '[vehicle]' then 
				category = 'vehicle'
			end	
			for coa, coa_tbl in pairs(l_munits) do
				for country, country_table in pairs(coa_tbl) do
					for unit_type, unit_type_tbl in pairs(country_table) do
						if type(unit_type_tbl) == 'table' and (category == '' or unit_type == category) then  
							for group_ind, group_tbl in pairs(unit_type_tbl) do
								if type(group_tbl) == 'table' then
									for unit_ind, unit in pairs(group_tbl.units) do
										if units_by_name[unit.unitName] then
											units_by_name[unit.unitName] = nil  --remove
										end
									end
								end
							end
						end
					end
				end
			end				
		else -- just a regular unit
			units_by_name[unit] = true  --add	
		end
	end
	
	local units_tbl = {}  -- indexed sequentially
	for unit_name, val in pairs(units_by_name) do
		if val then 
			units_tbl[#units_tbl + 1] = unit_name  -- add all the units to the table
		end
	end
	
	units_tbl['processed'] = true  --add the processed flag
	return units_tbl
end


mist.getDeadMapObjsInZones = function(zone_names)  
-- zone_names: table of zone names
-- returns: table of dead map objects (indexed numerically)
	local map_objs = {}
	local zones = {}
	for i = 1, #zone_names do
		if mist.DBs.zonesByName[zone_names[i]] then
			zones[#zones + 1] = mist.DBs.zonesByName[zone_names[i]]
		end
	end
	for obj_id, obj in pairs(mist.DBs.deadObjects) do
		if obj.objectType and obj.objectType == 'building' then --dead map object
			for i = 1, #zones do
				if ((zones[i].point.x - obj.objectPos.x)^2 + (zones[i].point.z - obj.objectPos.z)^2)^0.5 <= zones[i].radius then
					map_objs[#map_objs + 1] = mist.utils.deepCopy(obj)
				end
			end
		end
	end
	return map_objs
end


mist.getDeadMapObjsInPolygonZone = function(zone)  
-- zone_names: table of zone names
-- returns: table of dead map objects (indexed numerically)
	local map_objs = {}
	for obj_id, obj in pairs(mist.DBs.deadObjects) do
		if obj.objectType and obj.objectType == 'building' then --dead map object
			if mist.pointInPolygon(obj.objectPos, zone) then
				map_objs[#map_objs + 1] = mist.utils.deepCopy(obj)
			end
		end
	end
	return map_objs
end

mist.flagFunc = {}

mist.flagFunc.mapobjs_dead_zones = function(vars)
--[[vars needs to be:
zones = table or string,
flag = number,
stopflag = number or nil,
req_num = number or nil

AND used by function,
initial_number

]]
-- type_tbl
	local type_tbl = {
		[{'zones', 'zone'}] = {'table', 'string'},
		flag = 'number', 
		stopflag = {'number', 'nil'}, 
		[{'req_num', 'reqnum'}] = {'number', 'nil'},
	}
	
	local err, errmsg = mist.utils.typeCheck('mist.flagFunc.mapobjs_dead_zones', type_tbl, vars)
	assert(err, errmsg)
	local zones = vars.zones or vars.zone
	local flag = vars.flag
	local stopflag = vars.stopflag or -1
	local req_num = vars.req_num or vars.reqnum or 1
	local initial_number = vars.initial_number
	
	if type(zones) == 'string' then
		zones = {zones}
	end
	
	if not initial_number then 
		initial_number = #mist.getDeadMapObjsInZones(zones)
	end
	
	if stopflag == -1 or (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
		if (#mist.getDeadMapObjsInZones(zones) - initial_number) >= req_num then
			trigger.action.setUserFlag(flag, true)
			return
		else
			mist.scheduleFunction(mist.flagFunc.mapobjs_dead_zones, {{zones = zones, flag = flag, stopflag = stopflag, req_num = req_num, initial_number = initial_number}}, timer.getTime() + 1)
		end
	end
end



mist.flagFunc.mapobjs_dead_polygon = function(vars)
--[[vars needs to be:
zone = table,
flag = number,
stopflag = number or nil,
req_num = number or nil

AND used by function,
initial_number

]]
-- type_tbl
	local type_tbl = {
		[{'zone', 'polyzone'}] = 'table',
		flag = 'number', 
		stopflag = {'number', 'nil'}, 
		[{'req_num', 'reqnum'}] = {'number', 'nil'},
	}
	
	local err, errmsg = mist.utils.typeCheck('mist.flagFunc.mapobjs_dead_polygon', type_tbl, vars)
	assert(err, errmsg)
	local zone = vars.zone or vars.polyzone
	local flag = vars.flag
	local stopflag = vars.stopflag or -1
	local req_num = vars.req_num or vars.reqnum or 1
	local initial_number = vars.initial_number
	
	if not initial_number then 
		initial_number = #mist.getDeadMapObjsInPolygonZone(zone)
	end
	
	if stopflag == -1 or (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
		if (#mist.getDeadMapObjsInPolygonZone(zone) - initial_number) >= req_num then
			trigger.action.setUserFlag(flag, true)
			return
		else
			mist.scheduleFunction(mist.flagFunc.mapobjs_dead_polygon, {{zone = zone, flag = flag, stopflag = stopflag, req_num = req_num, initial_number = initial_number}}, timer.getTime() + 1)
		end
	end
end



function mist.pointInPolygon(point, poly, maxalt) --raycasting point in polygon. Code from http://softsurfer.com/Archive/algorithm_0103/algorithm_0103.htm
	point = mist.utils.makeVec3(point)
	local px = point.x
	local pz = point.z
	local cn = 0
	local newpoly = mist.utils.deepCopy(poly)
	
	if not maxalt or (point.y <= maxalt) then
		local polysize = #newpoly
		newpoly[#newpoly + 1] = newpoly[1]
		
		newpoly[1] = mist.utils.makeVec3(newpoly[1])
		
		for k = 1, polysize do
			newpoly[k+1] = mist.utils.makeVec3(newpoly[k+1])
			if ((newpoly[k].z <= pz) and (newpoly[k+1].z > pz)) or ((newpoly[k].z > pz) and (newpoly[k+1].z <= pz)) then 
				local vt = (pz - newpoly[k].z) / (newpoly[k+1].z - newpoly[k].z)
				if (px < newpoly[k].x + vt*(newpoly[k+1].x - newpoly[k].x)) then
				   cn = cn + 1    
				end
			end
		end
		
		return cn%2 == 1 
	else
		return false
	end
end


function mist.flagFunc.units_in_polygon(vars)
--[[vars needs to be:
units = table,
zone = table,
flag = number,
stopflag = number or nil,
maxalt = number or nil,
interval  = number or nil,
req_num = number or nil
]]
-- type_tbl
	local type_tbl = {
		[{'units', 'unit'}] = 'table', 
		[{'zone', 'polyzone'}] = 'table', 
		flag = 'number', 
		stopflag = {'number', 'nil'}, 
		[{'maxalt', 'alt'}] = {'number', 'nil'}, 
		interval = {'number', 'nil'}, 
		[{'req_num', 'reqnum'}] = {'number', 'nil'},
	}
	
	local err, errmsg = mist.utils.typeCheck('mist.flagFunc.units_in_polygon', type_tbl, vars)
	assert(err, errmsg)
	local units = vars.units or vars.unit
	local zone = vars.zone or vars.polyzone
	local flag = vars.flag
	local stopflag = vars.stopflag or -1
	local interval = vars.interval or 1
	local maxalt = vars.maxalt or vars.alt
	local req_num = vars.req_num or vars.reqnum or 1
	
	
	if not units.processed then -- run unit table short cuts
		units = mist.makeUnitTable(units)
	end
	
	if stopflag == -1 or (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
		local num_in_zone = 0
		for i = 1, #units do
			local unit = Unit.getByName(units[i])
			if unit then
				local pos = unit:getPosition().p
				if mist.pointInPolygon(pos, zone, maxalt) then
					num_in_zone = num_in_zone + 1
					if num_in_zone >= req_num then
						trigger.action.setUserFlag(flag, true)
						break
					end
				end
			end
		end
		-- do another check in case stopflag was set true by this function
		if (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
			mist.scheduleFunction(mist.flagFunc.units_in_polygon, {{units = units, zone = zone, flag = flag, stopflag = stopflag, interval = interval, req_num = req_num, maxalt = maxalt}}, timer.getTime() + interval)
		end
	end
end




function mist.getUnitsInZones(unit_names, zone_names, zone_type)
	
	zone_type = zone_type or 'cylinder'
	if zone_type == 'c' or zone_type == 'cylindrical' or zone_type == 'C' then
		zone_type = 'cylinder'
	end
	if zone_type == 's' or zone_type == 'spherical' or zone_type == 'S' then
		zone_type = 'sphere'
	end
	
	assert(zone_type == 'cylinder' or zone_type == 'sphere', 'invalid zone_type: ' .. tostring(zone_type))

	local units = {}
	local zones = {}

	for k = 1, #unit_names do
		local unit = Unit.getByName(unit_names[k])
		if unit then
			units[#units + 1] = unit
		end
	end
	
	for k = 1, #zone_names do
		local zone = trigger.misc.getZone(zone_names[k])
		if zone then
			zones[#zones + 1] = {radius = zone.radius, x = zone.point.x, y = zone.point.y, z = zone.point.z}
		end
	end
	
	local in_zone_units = {}
	
	for units_ind = 1, #units do
		for zones_ind = 1, #zones do
			if zone_type == 'sphere' then  --add land height value for sphere zone type
				local alt = land.getHeight({x = zones[zones_ind].x, y = zones[zones_ind].z})
				if alt then
					zones[zones_ind].y = alt
				end
			end
			local unit_pos = units[units_ind]:getPosition().p
			if unit_pos then
				if zone_type == 'cylinder' and (((unit_pos.x - zones[zones_ind].x)^2 + (unit_pos.z - zones[zones_ind].z)^2)^0.5 <= zones[zones_ind].radius) then
					in_zone_units[#in_zone_units + 1] = units[units_ind]
					break
				elseif zone_type == 'sphere' and (((unit_pos.x - zones[zones_ind].x)^2 + (unit_pos.y - zones[zones_ind].y)^2 + (unit_pos.z - zones[zones_ind].z)^2)^0.5 <= zones[zones_ind].radius) then
					in_zone_units[#in_zone_units + 1] = units[units_ind]
					break
				end
			end
		end
	end
	return in_zone_units
end


function mist.flagFunc.units_in_zones(vars)
	--[[vars needs to be:
	units = table,
	zones = table,
	flag = number,
	stopflag = number or nil,
	zone_type = string or nil,
	req_num = number or nil,
	interval  = number or nil
	]]
	-- type_tbl
	local type_tbl = {
		units = 'table', 
		zones = 'table', 
		flag = 'number', 
		stopflag = {'number', 'nil'}, 
		[{'zone_type', 'zonetype'}] = {'string', 'nil'}, 
		[{'req_num', 'reqnum'}] = {'number', 'nil'},
		interval = {'number', 'nil'}	
	}
	
	local err, errmsg = mist.utils.typeCheck('mist.flagFunc.units_in_zones', type_tbl, vars)
	assert(err, errmsg)
	local units = vars.units
	local zones = vars.zones
	local flag = vars.flag
	local stopflag = vars.stopflag or -1
	local zone_type = vars.zone_type or vars.zonetype or 'cylinder'
	local req_num = vars.req_num or vars.reqnum or 1
	local interval = vars.interval or 1
	
	
	if not units.processed then -- run unit table short cuts
		units = mist.makeUnitTable(units)
	end
	if stopflag == -1 or (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
	
		local in_zone_units = mist.getUnitsInZones(units, zones, zone_type)
	
		if #in_zone_units >= req_num then
			trigger.action.setUserFlag(flag, true)
		end		
		-- do another check in case stopflag was set true by this function
		if (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
			mist.scheduleFunction(mist.flagFunc.units_in_zones, {{units = units, zones = zones, flag = flag, stopflag = stopflag, zone_type = zone_type, req_num = req_num, interval = interval}}, timer.getTime() + interval)
		end
	end
	
end


function mist.getUnitsInMovingZones(unit_names, zone_unit_names, radius, zone_type)
	
	zone_type = zone_type or 'cylinder'
	if zone_type == 'c' or zone_type == 'cylindrical' or zone_type == 'C' then
		zone_type = 'cylinder'
	end
	if zone_type == 's' or zone_type == 'spherical' or zone_type == 'S' then
		zone_type = 'sphere'
	end
	
	assert(zone_type == 'cylinder' or zone_type == 'sphere', 'invalid zone_type: ' .. tostring(zone_type))

	local units = {}
	local zone_units = {}

	for k = 1, #unit_names do
		local unit = Unit.getByName(unit_names[k])
		if unit then
			units[#units + 1] = unit
		end
	end
	
	for k = 1, #zone_unit_names do
		local unit = Unit.getByName(zone_unit_names[k])
		if unit then
			zone_units[#zone_units + 1] = unit
		end
	end

	local in_zone_units = {}
	
	for units_ind = 1, #units do
		for zone_units_ind = 1, #zone_units do
			local unit_pos = units[units_ind]:getPosition().p
			local zone_unit_pos = zone_units[zone_units_ind]:getPosition().p
			if unit_pos and zone_unit_pos then
				if zone_type == 'cylinder' and (((unit_pos.x - zone_unit_pos.x)^2 + (unit_pos.z - zone_unit_pos.z)^2)^0.5 <= radius) then
					in_zone_units[#in_zone_units + 1] = units[units_ind]
					break
				elseif zone_type == 'sphere' and (((unit_pos.x - zone_unit_pos.x)^2 + (unit_pos.y - zone_unit_pos.y)^2 + (unit_pos.z - zone_unit_pos.z)^2)^0.5 <= radius) then
					in_zone_units[#in_zone_units + 1] = units[units_ind]
					break
				end
			end
		end
	end
	return in_zone_units
end



function mist.flagFunc.units_in_moving_zones(vars)
	--[[vars needs to be:
	units = table,
	zone_units = table,
	radius = number,
	flag = number,
	stopflag = number or nil,
	zone_type = string or nil,
	req_num = number or nil,
	interval  = number or nil
	]]
	-- type_tbl
	local type_tbl = {
		units = 'table', 
		[{'zone_units', 'zoneunits'}]  = 'table', 
		radius = 'number',
		flag = 'number', 
		stopflag = {'number', 'nil'}, 
		[{'zone_type', 'zonetype'}] = {'string', 'nil'}, 
		[{'req_num', 'reqnum'}] = {'number', 'nil'},
		interval = {'number', 'nil'}	
	}
	
	local err, errmsg = mist.utils.typeCheck('mist.flagFunc.units_in_moving_zones', type_tbl, vars)
	assert(err, errmsg)
	local units = vars.units
	local zone_units = vars.zone_units or vars.zoneunits
	local radius = vars.radius
	local flag = vars.flag
	local stopflag = vars.stopflag or -1
	local zone_type = vars.zone_type or vars.zonetype or 'cylinder'
	local req_num = vars.req_num or vars.reqnum or 1
	local interval = vars.interval or 1
	
	if not units.processed then -- run unit table short cuts
		units = mist.makeUnitTable(units)
	end
	
	if not zone_units.processed then -- run unit table short cuts
		zone_units = mist.makeUnitTable(zone_units)
	end
	
	if stopflag == -1 or (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
	
		local in_zone_units = mist.getUnitsInMovingZones(units, zone_units, radius, zone_type)
	
		if #in_zone_units >= req_num then
			trigger.action.setUserFlag(flag, true)
		end		
		-- do another check in case stopflag was set true by this function
		if (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
			mist.scheduleFunction(mist.flagFunc.units_in_moving_zones, {{units = units, zone_units = zone_units, radius = radius, flag = flag, stopflag = stopflag, zone_type = zone_type, req_num = req_num, interval = interval}}, timer.getTime() + interval)
		end
	end
	
end


mist.getUnitsLOS = function(unitset1, altoffset1, unitset2, altoffset2, radius)
	radius = radius or math.huge
	
	local unit_info1 = {}
	local unit_info2 = {}
	
	-- get the positions all in one step, saves execution time.
	for unitset1_ind = 1, #unitset1 do
		local unit1 = Unit.getByName(unitset1[unitset1_ind])
		if unit1 then
			unit_info1[#unit_info1 + 1] = {}
			unit_info1[#unit_info1]["unit"] = unit1
			unit_info1[#unit_info1]["pos"]  = unit1:getPosition().p
		end
	end
	
	for unitset2_ind = 1, #unitset2 do
		local unit2 = Unit.getByName(unitset2[unitset2_ind])
		if unit2 then
			unit_info2[#unit_info2 + 1] = {}
			unit_info2[#unit_info2]["unit"] = unit2
			unit_info2[#unit_info2]["pos"]  = unit2:getPosition().p
		end
	end

	local LOS_data = {}
	-- now compute los
	for unit1_ind = 1, #unit_info1 do
		local unit_added = false
		for unit2_ind = 1, #unit_info2 do
			if radius == math.huge or (mist.vec.mag(mist.vec.sub(unit_info1[unit1_ind].pos, unit_info2[unit2_ind].pos)) < radius) then -- inside radius
				local point1 = { x = unit_info1[unit1_ind].pos.x, y = unit_info1[unit1_ind].pos.y + altoffset1, z = unit_info1[unit1_ind].pos.z}
				local point2 = { x = unit_info2[unit2_ind].pos.x, y = unit_info2[unit2_ind].pos.y + altoffset2, z = unit_info2[unit2_ind].pos.z}
				if land.isVisible(point1, point2) then
					if unit_added == false then
						unit_added = true
						LOS_data[#LOS_data + 1] = {}
						LOS_data[#LOS_data]['unit'] = unit_info1[unit1_ind].unit
						LOS_data[#LOS_data]['vis'] = {}
						LOS_data[#LOS_data]['vis'][#LOS_data[#LOS_data]['vis'] + 1] = unit_info2[unit2_ind].unit 
					else
						LOS_data[#LOS_data]['vis'][#LOS_data[#LOS_data]['vis'] + 1] = unit_info2[unit2_ind].unit 
					end
				end
			end
		end
	end
	
	return LOS_data
end

mist.flagFunc.units_LOS = function(vars)
--[[vars needs to be:
unitset1 = table, 
altoffset1 = number, 
unitset2 = table, 
altoffset2 = number,
flag = number,
stopflag = number or nil,
radius = number or nil,
interval  = number or nil,
req_num = number or nil
]]
-- type_tbl
	local type_tbl = {
		[{'unitset1', 'units1'}] = 'table', 
		[{'altoffset1', 'alt1'}] = 'number', 
		[{'unitset2', 'units2'}] = 'table', 
		[{'altoffset2', 'alt2'}] = 'number', 
		flag = 'number', 
		stopflag = {'number', 'nil'}, 
		[{'req_num', 'reqnum'}] = {'number', 'nil'}, 
		interval = {'number', 'nil'}, 
		radius = {'number', 'nil'}
	}
	
	local err, errmsg = mist.utils.typeCheck('mist.flagFunc.units_LOS', type_tbl, vars)
	assert(err, errmsg)
	local unitset1 = vars.unitset1 or vars.units1
	local altoffset1 = vars.altoffset1 or vars.alt1
	local unitset2 = vars.unitset2 or vars.units2
	local altoffset2 = vars.altoffset2 or vars.alt2
	local flag = vars.flag
	local stopflag = vars.stopflag or -1
	local interval = vars.interval or 1
	local radius = vars.radius or math.huge
	local req_num = vars.req_num or vars.reqnum or 1
	
	
	if not unitset1.processed then -- run unit table short cuts
		unitset1 = mist.makeUnitTable(unitset1)
	end
	
	if not unitset2.processed then -- run unit table short cuts
		unitset2 = mist.makeUnitTable(unitset2)
	end
	
	if stopflag == -1 or (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
	
		local unitLOSdata = mist.getUnitsLOS(unitset1, altoffset1, unitset2, altoffset2, radius)
	
		if #unitLOSdata >= req_num then
			trigger.action.setUserFlag(flag, true)
		end		
		-- do another check in case stopflag was set true by this function
		if (type(trigger.misc.getUserFlag(stopflag)) == 'number' and trigger.misc.getUserFlag(stopflag) == 0) or (type(trigger.misc.getUserFlag(stopflag)) == 'boolean' and trigger.misc.getUserFlag(stopflag) == false) then
			mist.scheduleFunction(mist.flagFunc.units_LOS, {{unitset1 = unitset1, altoffset1 = altoffset1, unitset2 = unitset2, altoffset2 = altoffset2, flag = flag, stopflag = stopflag, radius = radius, req_num = req_num, interval = interval}}, timer.getTime() + interval)
		end
	end
	

end


---------------------------------------------------------------------------------------
-- demos
mist.demos = {}

mist.demos.printFlightData = function(unit)
	if unit:isExist() then
		local function printData(unit, prevVel, prevE, prevTime)
			local angles = mist.getAttitude(unit)
			if angles then
				local Heading = angles.Heading
				local Pitch = angles.Pitch
				local Roll = angles.Roll
				local Yaw = angles.Yaw
				local AoA = angles.AoA
				local ClimbAngle = angles.ClimbAngle
				
				if not Heading then
					Heading = 'NA'
				else
					Heading = string.format('%12.2f', mist.utils.toDegree(Heading))
				end
				
				if not Pitch then
					Pitch = 'NA'
				else
					Pitch = string.format('%12.2f', mist.utils.toDegree(Pitch))
				end
				
				if not Roll then 
					Roll = 'NA'
				else
					Roll = string.format('%12.2f', mist.utils.toDegree(Roll))
				end
				
				local AoAplusYaw = 'NA'
				if AoA and Yaw then
					AoAplusYaw = string.format('%12.2f', mist.utils.toDegree((AoA^2 + Yaw^2)^0.5))
				end
				
				if not Yaw then
					Yaw = 'NA'
				else
					Yaw = string.format('%12.2f', mist.utils.toDegree(Yaw))
				end
				
				if not AoA then
					AoA = 'NA'
				else
					AoA = string.format('%12.2f', mist.utils.toDegree(AoA))
				end
				
				if not ClimbAngle then 
					ClimbAngle = 'NA'
				else
					ClimbAngle = string.format('%12.2f', mist.utils.toDegree(ClimbAngle))
				end
				local unitPos = unit:getPosition()
				local unitVel = unit:getVelocity()
				local curTime = timer.getTime()
				local absVel = string.format('%12.2f', mist.vec.mag(unitVel))
				
				
				local unitAcc = 'NA'
				local Gs = 'NA'
				local axialGs = 'NA'
				local transGs = 'NA'
				if prevVel and prevTime then
					xAcc = (unitVel.x - prevVel.x)/(curTime - prevTime)
					yAcc = (unitVel.y - prevVel.y)/(curTime - prevTime)
					zAcc = (unitVel.z - prevVel.z)/(curTime - prevTime)
					
					unitAcc = string.format('%12.2f', mist.vec.mag({x = xAcc, y = yAcc, z = zAcc}))
					Gs = string.format('%12.2f', mist.vec.mag({x = xAcc, y = yAcc + 9.81, z = zAcc})/9.81)
					axialGs = string.format('%12.2f', mist.vec.dp({x = xAcc, y = yAcc + 9.81, z = zAcc}, unitPos.x)/9.81)
					transGs = string.format('%12.2f', mist.vec.mag(mist.vec.cp({x = xAcc, y = yAcc + 9.81, z = zAcc}, unitPos.x))/9.81)
				end
				
				local E = 0.5*mist.vec.mag(unitVel)^2 + 9.81*unitPos.p.y
				
				local energy = string.format('%12.2e', E)
				
				local dEdt = 'NA'
				if prevE and prevTime then
					dEdt = string.format('%12.2e', (E - prevE)/(curTime - prevTime))
				end
				
				trigger.action.outText(string.format('%-25s', 'Heading: ') .. Heading .. ' degrees\n' .. string.format('%-25s', 'Roll: ') .. Roll .. ' degrees\n' .. string.format('%-25s', 'Pitch: ') .. Pitch
													.. ' degrees\n' .. string.format('%-25s', 'Yaw: ') .. Yaw .. ' degrees\n' .. string.format('%-25s', 'AoA: ') .. AoA .. ' degrees\n' .. string.format('%-25s', 'AoA plus Yaw: ') .. AoAplusYaw .. ' degrees\n' .. string.format('%-25s', 'Climb Angle: ') .. 
													ClimbAngle .. ' degrees\n' .. string.format('%-25s', 'Absolute Velocity: ') .. absVel .. ' m/s\n' .. string.format('%-25s', 'Absolute Acceleration: ') .. unitAcc ..' m/s^2\n'
													.. string.format('%-25s', 'Axial G loading: ') .. axialGs .. ' g\n' .. string.format('%-25s', 'Transverse G loading: ') .. transGs .. ' g\n' .. string.format('%-25s', 'Absolute G loading: ') .. Gs .. ' g\n' .. string.format('%-25s', 'Energy: ') .. energy .. ' J/kg\n' .. string.format('%-25s', 'dE/dt: ') .. dEdt .. 
													' J/(kg*s)', 1)

				return unitVel, E, curTime
			end
		end
		
		local function frameFinder(unit, prevVel, prevE, prevTime)
			if unit:isExist() then
				local currVel = unit:getVelocity()
				if prevVel and (prevVel.x ~= currVel.x or prevVel.y ~= currVel.y or prevVel.z ~= currVel.z) or (prevTime and (timer.getTime() - prevTime) > 0.25) then
					prevVel, prevE, prevTime = printData(unit, prevVel, prevE, prevTime)
				end
				mist.scheduleFunction(frameFinder, {unit, prevVel, prevE, prevTime}, timer.getTime() + 0.005)  -- it can't go this fast, limited to the 100 times a sec check right now.
			end
		end
		
		
		local curVel = unit:getVelocity()
		local curTime = timer.getTime()
		local curE = 0.5*mist.vec.mag(curVel)^2 + 9.81*unit:getPosition().p.y
		frameFinder(unit, curVel, curE, curTime)
	
	end
	
end

mist.main()
print('Mist version ' .. mist.majorVersion .. '.' .. mist.minorVersion .. '.' .. mist.build .. ' loaded.')